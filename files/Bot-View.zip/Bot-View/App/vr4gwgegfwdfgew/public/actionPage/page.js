let goldenRatio = 1.61803398875
let pageWidth = 340

var Constant = {
    pageHeight: goldenRatio * 340,
    pageContainerHeight: goldenRatio * 340 - 95,
    standalonePageHeight: goldenRatio * 340 + 20,
    pageWidth: pageWidth,

    menuBarHeight: 42,
    searchWidth: 260,


    noteModalContentHeight: 170,


    color: {
        red: '#DB2828',
        orange: '#E55B00',
        'yellow': '#FBBD08',
        'olive': '#B5CC18',
        'green': '#21BA45',
        'teal': '#00B5AD',
        'blue': '#2185D0',
        'violet': '#6435C9',
        purple: '#A333C8',
        pink: '#E03997',
        deepgreen: '#2E7D32',
        brown: '#A52A2A',
        grey: '#767676',
        black: '#000000',
        white: '#ffffff',
        lightGrey: '#EDEDED',
        darkerGrey: '#504b4a'
    }
};

window.Constant = Constant;
// window.document.body.style.height = Constant.pageHeight + 'px';
window.document.body.style.width = Constant.pageWidth + 'px';
window.document.body.style.minWidth = Constant.pageWidth + 'px';
