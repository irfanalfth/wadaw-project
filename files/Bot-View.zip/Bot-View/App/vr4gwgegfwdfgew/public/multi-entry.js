'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function getAugmentedNamespace(n) {
	if (n.__esModule) return n;
	var a = Object.defineProperty({}, '__esModule', {value: true});
	Object.keys(n).forEach(function (k) {
		var d = Object.getOwnPropertyDescriptor(n, k);
		Object.defineProperty(a, k, d.get ? d : {
			enumerable: true,
			get: function () {
				return n[k];
			}
		});
	});
	return a;
}

function createCommonjsModule(fn) {
  var module = { exports: {} };
	return fn(module, module.exports), module.exports;
}

/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var runtime_1 = createCommonjsModule(function (module) {
var runtime = (function (exports) {

  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined$1; // More compressible than void 0.
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";

  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);

    // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.
    generator._invoke = makeInvokeMethod(innerFn, self, context);

    return generator;
  }
  exports.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return { type: "normal", arg: fn.call(obj, arg) };
    } catch (err) {
      return { type: "throw", arg: err };
    }
  }

  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  // This is a polyfill for %IteratorPrototype% for environments that
  // don't natively support it.
  var IteratorPrototype = {};
  IteratorPrototype[iteratorSymbol] = function () {
    return this;
  };

  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype &&
      NativeIteratorPrototype !== Op &&
      hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
  }

  var Gp = GeneratorFunctionPrototype.prototype =
    Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunctionPrototype[toStringTagSymbol] =
    GeneratorFunction.displayName = "GeneratorFunction";

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      prototype[method] = function(arg) {
        return this._invoke(method, arg);
      };
    });
  }

  exports.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor
      ? ctor === GeneratorFunction ||
        // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction"
      : false;
  };

  exports.mark = function(genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      if (!(toStringTagSymbol in genFun)) {
        genFun[toStringTagSymbol] = "GeneratorFunction";
      }
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `hasOwn.call(value, "__await")` to determine if the yielded value is
  // meant to be awaited.
  exports.awrap = function(arg) {
    return { __await: arg };
  };

  function AsyncIterator(generator, PromiseImpl) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value &&
            typeof value === "object" &&
            hasOwn.call(value, "__await")) {
          return PromiseImpl.resolve(value.__await).then(function(value) {
            invoke("next", value, resolve, reject);
          }, function(err) {
            invoke("throw", err, resolve, reject);
          });
        }

        return PromiseImpl.resolve(value).then(function(unwrapped) {
          // When a yielded Promise is resolved, its final value becomes
          // the .value of the Promise<{value,done}> result for the
          // current iteration.
          result.value = unwrapped;
          resolve(result);
        }, function(error) {
          // If a rejected Promise was yielded, throw the rejection back
          // into the async generator function so it can be handled there.
          return invoke("throw", error, resolve, reject);
        });
      }
    }

    var previousPromise;

    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new PromiseImpl(function(resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }

      return previousPromise =
        // If enqueue has been called before, then we want to wait until
        // all previous Promises have been resolved before calling invoke,
        // so that results are always delivered in the correct order. If
        // enqueue has not been called before, then it is important to
        // call invoke immediately, without waiting on a callback to fire,
        // so that the async generator function has the opportunity to do
        // any necessary setup in a predictable way. This predictability
        // is why the Promise constructor synchronously invokes its
        // executor callback, and why async functions synchronously
        // execute code before the first await. Since we implement simple
        // async functions in terms of async generators, it is especially
        // important to get this right, even though it requires care.
        previousPromise ? previousPromise.then(
          callInvokeWithMethodAndArg,
          // Avoid propagating failures to Promises returned by later
          // invocations of the iterator.
          callInvokeWithMethodAndArg
        ) : callInvokeWithMethodAndArg();
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    this._invoke = enqueue;
  }

  defineIteratorMethods(AsyncIterator.prototype);
  AsyncIterator.prototype[asyncIteratorSymbol] = function () {
    return this;
  };
  exports.AsyncIterator = AsyncIterator;

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  exports.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
    if (PromiseImpl === void 0) PromiseImpl = Promise;

    var iter = new AsyncIterator(
      wrap(innerFn, outerFn, self, tryLocsList),
      PromiseImpl
    );

    return exports.isGeneratorFunction(outerFn)
      ? iter // If outerFn is a generator, return the full iterator.
      : iter.next().then(function(result) {
          return result.done ? result.value : iter.next();
        });
  };

  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;

    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }

      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }

      context.method = method;
      context.arg = arg;

      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }

        if (context.method === "next") {
          // Setting context._sent for legacy support of Babel's
          // function.sent implementation.
          context.sent = context._sent = context.arg;

        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }

          context.dispatchException(context.arg);

        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }

        state = GenStateExecuting;

        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done
            ? GenStateCompleted
            : GenStateSuspendedYield;

          if (record.arg === ContinueSentinel) {
            continue;
          }

          return {
            value: record.arg,
            done: context.done
          };

        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(context.arg) call above.
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }

  // Call delegate.iterator[context.method](context.arg) and handle the
  // result, either by returning a { value, done } result from the
  // delegate iterator, or by modifying context.method and context.arg,
  // setting context.delegate to null, and returning the ContinueSentinel.
  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];
    if (method === undefined$1) {
      // A .throw or .return when the delegate iterator has no .throw
      // method always terminates the yield* loop.
      context.delegate = null;

      if (context.method === "throw") {
        // Note: ["return"] must be used for ES3 parsing compatibility.
        if (delegate.iterator["return"]) {
          // If the delegate iterator has a return method, give it a
          // chance to clean up.
          context.method = "return";
          context.arg = undefined$1;
          maybeInvokeDelegate(delegate, context);

          if (context.method === "throw") {
            // If maybeInvokeDelegate(context) changed context.method from
            // "return" to "throw", let that override the TypeError below.
            return ContinueSentinel;
          }
        }

        context.method = "throw";
        context.arg = new TypeError(
          "The iterator does not provide a 'throw' method");
      }

      return ContinueSentinel;
    }

    var record = tryCatch(method, delegate.iterator, context.arg);

    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }

    var info = record.arg;

    if (! info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }

    if (info.done) {
      // Assign the result of the finished delegate to the temporary
      // variable specified by delegate.resultName (see delegateYield).
      context[delegate.resultName] = info.value;

      // Resume execution at the desired location (see delegateYield).
      context.next = delegate.nextLoc;

      // If context.method was "throw" but the delegate handled the
      // exception, let the outer generator proceed normally. If
      // context.method was "next", forget context.arg since it has been
      // "consumed" by the delegate iterator. If context.method was
      // "return", allow the original .return call to continue in the
      // outer generator.
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined$1;
      }

    } else {
      // Re-yield the result returned by the delegate method.
      return info;
    }

    // The delegate iterator is finished, so forget it and continue with
    // the outer generator.
    context.delegate = null;
    return ContinueSentinel;
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);

  Gp[toStringTagSymbol] = "Generator";

  // A Generator should always return itself as the iterator object when the
  // @@iterator function is called on it. Some browsers' implementations of the
  // iterator prototype chain incorrectly implement this, causing the Generator
  // object to not be returned from this call. This ensures that doesn't happen.
  // See https://github.com/facebook/regenerator/issues/274 for more details.
  Gp[iteratorSymbol] = function() {
    return this;
  };

  Gp.toString = function() {
    return "[object Generator]";
  };

  function pushTryEntry(locs) {
    var entry = { tryLoc: locs[0] };

    if (1 in locs) {
      entry.catchLoc = locs[1];
    }

    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }

    this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }

  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{ tryLoc: "root" }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }

  exports.keys = function(object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }

      if (typeof iterable.next === "function") {
        return iterable;
      }

      if (!isNaN(iterable.length)) {
        var i = -1, next = function next() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next.value = iterable[i];
              next.done = false;
              return next;
            }
          }

          next.value = undefined$1;
          next.done = true;

          return next;
        };

        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return { next: doneResult };
  }
  exports.values = values;

  function doneResult() {
    return { value: undefined$1, done: true };
  }

  Context.prototype = {
    constructor: Context,

    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      // Resetting context._sent for legacy support of Babel's
      // function.sent implementation.
      this.sent = this._sent = undefined$1;
      this.done = false;
      this.delegate = null;

      this.method = "next";
      this.arg = undefined$1;

      this.tryEntries.forEach(resetTryEntry);

      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" &&
              hasOwn.call(this, name) &&
              !isNaN(+name.slice(1))) {
            this[name] = undefined$1;
          }
        }
      }
    },

    stop: function() {
      this.done = true;

      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }

      return this.rval;
    },

    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }

      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;

        if (caught) {
          // If the dispatched exception was caught by a catch block,
          // then let that catch block handle the exception normally.
          context.method = "next";
          context.arg = undefined$1;
        }

        return !! caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;

        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }

          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },

    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev &&
            hasOwn.call(entry, "finallyLoc") &&
            this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      if (finallyEntry &&
          (type === "break" ||
           type === "continue") &&
          finallyEntry.tryLoc <= arg &&
          arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }

      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;

      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }

      return this.complete(record);
    },

    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }

      if (record.type === "break" ||
          record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }

      return ContinueSentinel;
    },

    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },

    "catch": function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },

    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };

      if (this.method === "next") {
        // Deliberately forget the last sent value so that we don't
        // accidentally pass it on to the delegate.
        this.arg = undefined$1;
      }

      return ContinueSentinel;
    }
  };

  // Regardless of whether this script is executing as a CommonJS module
  // or not, return the runtime object so that we can declare the variable
  // regeneratorRuntime in the outer scope, which allows this module to be
  // injected easily by `bin/regenerator --include-runtime script.js`.
  return exports;

}(
  // If this script is executing as a CommonJS module, use module.exports
  // as the regeneratorRuntime namespace. Otherwise create a new empty
  // object. Either way, the resulting object will be used to initialize
  // the regeneratorRuntime variable at the top of this file.
  module.exports 
));

try {
  regeneratorRuntime = runtime;
} catch (accidentalStrictMode) {
  // This module should not be running in strict mode, so the above
  // assignment should always work unless something is misconfigured. Just
  // in case runtime.js accidentally runs in strict mode, we can escape
  // strict mode using a global Function call. This could conceivably fail
  // if a Content Security Policy forbids using Function, but in that case
  // the proper solution is to fix the accidental strict mode problem. If
  // you've misconfigured your bundler to force strict mode and applied a
  // CSP to forbid Function, and you're not willing to fix either of those
  // problems, please detail your unique predicament in a GitHub issue.
  Function("r", "regeneratorRuntime = r")(runtime);
}
});

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

var classCallCheck = _classCallCheck;

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

var createClass = _createClass;

var ee = require('./_utilities/event-emitter'); // polyfill


require('./_utilities/polyfill/weakmap');

require('./_utilities/polyfill/promise');

var Runtime$1 = /*#__PURE__*/function () {
  function Runtime(lst) {
    classCallCheck(this, Runtime);

    var self = this;
    self.eventEmitter = new ee();
    window.BeenoteEventHub = self.eventEmitter;
    self.programList = [];
    lst.forEach(function (p) {
      self.programList.push(p);
    });
  }

  createClass(Runtime, [{
    key: "start",
    value: function start() {
      this.programList.forEach(function (p) {
        return p();
      });
    }
  }]);

  return Runtime;
}();

module.exports = Runtime$1;

var runtime = /*#__PURE__*/Object.freeze({
	__proto__: null
});

var exportedEvent = {};
var EVENTS = ["Alert", "UserSelection", // => {Selection} Object
"UserMouseDown", "UserMouseMove", "UserMouseUp", "UserSelecting", // => {DomEvent}
"UserEnterRightTop", "UserLeaveRightTop", "TooltipClick", // => [{String} button name, {Selection} Object]
"WindowResize", "SaveNote", "DeleteNote", "DeleteNoteExternally", // => {BaseNote}
"FetchNoteList", "ReceiveNoteList", // => {[BaseNote]}
"PageChanged", "ContextMenuClick", "CommentOnHighlight", "ShareNotePage", "GetWebpageInfo", "PushWebpageInfo", // => {PageInfo}
"DisablePage", "EnablePage", "CheckBlackList", "AddBlackList", "RemoveBlackList", "GetRecentNotes", "ReceiveRecentNotes", "FetchPageHTMLNotes", "LOG_INFO", "LOG_WARNING", "LOG_ERROR", "LOG_SUCCESS", // @comment: move all export to background, frontend only for debugging
"GetNoteHTMLWordDebug", // "ReceiveNoteHTMLWord", "ReceiveNoteHTMLEvernote",
"GetImageInBackground", "FacebookOAuthLogin", "GoogleOAuthLogin", "ActionPageNotification", "Login", "LoginSuccessfully"];
EVENTS.forEach(function (key) {
  return exportedEvent[key] = key;
});
var events$2 = exportedEvent;

var DEBUG = process.env.NODE_ENV == 'development';
var frontend = {
  debug: DEBUG,
  logEvents: [],
  constant: {
    XPathCondition: {
      TAG_NAME_ONLY: 0
    },
    PointInRange: {
      Tooltip: 1,
      Note: 0,
      Outside: -1
    }
  },
  googleQueryURL: 'http://google.com/search?q=',
  noteEvent: ['remove', 'hover'],
  global: {
    /** defined in runtime.js */
    get BeenoteEventHub() {
      return window.BeenoteEventHub;
    },

    /** defined in uiListener/mouseMovement.js */
    get IsSelecting() {
      //
      return window.IsSelecting;
    }

  },
  highlightColor: {
    "default": 'yellow',
    palette: {
      'red': '#FDC3D3',
      'green': '#CEF5C5',
      // Tea Green
      'yellow': '#F9DB95',
      'blue': '#6CB1EF'
    },
    strong: {
      'red': '#84334a',
      'green': '#469106',
      'yellow': '#9d8d49',
      'blue': '#4682b4'
    }
  }
};

var activityLog = function () {
  var hub = window.BeenoteEventHub;

  if (frontend.debug) {
    hub.on(events$2.LOG_INFO, function (arg) {
      console.info(arg);
    });
    hub.on(events$2.LOG_WARNING, function (arg) {
      console.warn(arg);
    });
    hub.on(events$2.LOG_ERROR, function (arg) {
      console.error(arg);
    });
    hub.on(events$2.LOG_SUCCESS, function (arg) {
      var data = {
        icon: "\u2713",
        greenBg: "background-color: green;",
        greenFg: "color: green;",
        whiteFg: "color: white;"
      };
      console.log("%c ".concat(data.icon, " ") + "%c ".concat(args), "".concat(data.greenBg, " ").concat(data.whiteFg), data.greenFg);
    });
  } // log selected event


  frontend.logEvents.forEach(function (eventName) {
    hub.on(eventName, function (arg) {
      console.log("Events: " + eventName);
      console.dir(arg);
    });
  });
};

/**
 * Send message to background, function for chrome.
 * @param{Object} message - the JSON object that will be sent
 * @param{requestCallback} callback - the callback function that handle the reply
 */
function chromeSendMessage(message, callback) {
  callback = callback || function () {};

  chrome.runtime.sendMessage(message, function (response) {
    if (response) callback(response);else callback(response);
    return true;
  });
}

function chromeSendMessageToTab(tabId, message, callback) {
  chrome.tabs.sendMessage(tabId, message, callback);
}
/**
 * Receive message from background, function for chrome.
 * @param{requestCallback} callback - the callback function that handle the reply
 */


function chromeOnMessage$1(callback) {
  chrome.runtime.onMessage.addListener(function (req, sender, res) {
    return callback(req, sender, res);
  });
}
/**
 * Send a message to a certain tab
 * @param{tab} tab - the tab element
 * @param{tab} message - the message to send
 * @param{callback} callback - the callback function to use after sendMessage returned.
 */


function sendMessageToTab(tab, message) {
  var callback = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : function () {};
  chromeSendMessageToTab(tab.id, message, callback);
}
/**
 * Generic receive message function, will support other browser later.
 * @param{requestCallback} callback - the callback function that handle the reply
 */


function onMessage$4(callback) {
  var wrapper = function wrapper(request, sender, sendResponse) {
    callback(request, sender, sendResponse);
    return true;
  };

  return chromeOnMessage$1(wrapper);
}
/**
 * Generic send message function, will support other browser later.
 * @param{Object} message - the JSON object that will be sent
 * @param{requestCallback} callback - the callback function that handle the reply
 */


function sendMessage$1(message, callback) {
  return chromeSendMessage(message, callback);
}
/**
 * handle chrome background page cold-start problem
 */


function sendMessageWithRetry(message, callback, retryTestCallback) {
  retryTestCallback = retryTestCallback || function (a) {
    return a;
  };

  var status = {
    isRespond: false
  };
  sendMessage$1(message, function (res) {
    if (!retryTestCallback(res)) {
      status.isRespond = true;
      callback(res);
    }
  });
  setTimeout(function () {
    if (!status.isRespond) {
      sendMessage$1(message, function (res) {
        status.isRespond = true;
        callback(res);
      });
    }
  }, 300);
}

function createMessage$1(messageType, content) {
  return {
    type: messageType,
    content: content
  };
}
/**
 *
 * @param {String} pname - name of the permission, like "downloads"
 */


function requestPermission$1(pname, callback) {
  var arg = {
    permissions: [pname]
  };
  chrome.permissions.contains(arg, function (has) {
    if (has) {
      callback();
    } else {
      chrome.permissions.request(arg, function (granted) {
        if (granted) {
          callback();
        }
      });
    }
  });
}

function downloadOnlineFile$1(link, filename, callback) {
  chrome.downloads.download({
    url: link,
    filename: filename
  }, callback);
}
/**
 * set the text on the popup icon to notify user that there is an update.
 */


function setUpdateBadge() {
  chrome.runtime.onInstalled.addListener(function (details) {
    if (details.reason == "update") {
      chrome.runtime.getManifest().version; // if (details.previousVersion != thisVersion) {

      chrome.browserAction.setBadgeText({
        text: 'new'
      }); // }
    } else {
      chrome.browserAction.setBadgeText({
        text: ''
      });
    }
  });
}

function resetUpdateBadge() {
  chrome.browserAction.setBadgeText({
    text: ''
  });
}

function isUpdateBadge(callback) {
  chrome.browserAction.getBadgeText({}, function (text) {
    if (text == 'new') callback();
  });
}

var communicate = {
  sendMessage: sendMessage$1,
  sendMessageToTab: sendMessageToTab,
  onMessage: onMessage$4,
  createMessage: createMessage$1,
  sendMessageWithRetry: sendMessageWithRetry,
  downloadOnlineFile: downloadOnlineFile$1,
  requestPermission: requestPermission$1,
  setUpdateBadge: setUpdateBadge,
  resetUpdateBadge: resetUpdateBadge,
  isUpdateBadge: isUpdateBadge
};

var exportedMessage = {};
var MESSAGE = [//"AddNote",
//"UpdateNote",
"SaveNote", "RemoveNote", "FetchNoteList", "SearchWebPage", "FetchTotalPageData", "CheckBlackList", "AddBlackList", "RemoveBlackList", "EnablePage", "GetRecentNotes", "LoadSharedNotes", "CreateSharedLink", // Note exporting
// "RequestExportingWord", "RequestExportingEvernote",
"GenerateExportedWord", "GenerateExportedEvernote", "GetImageInBackground", // content-script with popup
"GetCurrentPageHTMLNotes", "JumpToNoteInPage", "DeleteNoteExternally", "FacebookOAuthLogin", "GoogleOAuthLogin", // events send from actionPage to extension background
"UserLogin", "UserRegister", "UserLogout", "AnalyticsLog"];
MESSAGE.forEach(function (key) {
  return exportedMessage[key] = key;
});
var Message = exportedMessage;

/**
 * get the searching index for the document in the pouchdb
 * @param {URL} - the json object for window.location
 * @return {string} 
 */
function getSearchIndexLegacy(urlInfo) {
  // this could be more complex in the future.
  var index = urlInfo.origin + urlInfo.pathname;

  if (index.substring(index.length - 11) == '/index.html') {
    index = index.substring(0, index.length - 10); // we keep the '/'
  } else if (index.substring(index.length - 10) == '/index.htm') {
    index = index.substring(0, index.length - 9);
  }

  return index;
}
/**
 * get the searching index for the document in the pouchdb
 * @param {URL} - the json object for window.location
 * @return {string} 
 */


function getSearchIndex(urlInfo) {
  var path = getSearchIndexLegacy(urlInfo);
  var search = getQueryParametersIndex(urlInfo);
  return path + search;
}
/**
 * @param {URL} url - URL object
 * @return {string} 
 */


function getQueryParametersIndex(url) {
  if (url.search) {
    var param = new URLSearchParams(url.search);
    param.sort();
    return '?' + param.toString();
  } else {
    return '';
  }
}

var searchIndex$2 = {
  getSearchIndex: getSearchIndex,
  getSearchIndexLegacy: getSearchIndexLegacy
};

var UrlInfo$1 = require('../uiRender/UrlInfo');

var searchIndex$1 = require('./searchIndex');

var WebPageInfo$1 = /*#__PURE__*/function () {
  function WebPageInfo(object) {
    classCallCheck(this, WebPageInfo);

    if (object) {
      this.urlInfo = new UrlInfo$1(object.urlInfo);
      this.title = object.title;
      this.description = object.description;
      this.keywords = object.keywords;
      this.favicon = object.favicon;
    } else {
      this.urlInfo = new UrlInfo$1(window.location);
      this.title = document.title;
      this.description = this.getDescription();
      this.keywords = this.getKeywords();
      this.favicon = "";
    }
  }

  createClass(WebPageInfo, [{
    key: "getDescription",
    value: function getDescription() {
      var domList = document.getElementsByName('description');

      if (domList.length > 0) {
        return domList[0].content;
      }

      return "";
    }
  }, {
    key: "getKeywords",
    value: function getKeywords() {
      var domList = document.getElementsByName('keywords');

      if (domList.length > 0) {
        return domList[0].content;
      }

      return "";
    }
  }, {
    key: "getWebpageIndex",
    value: function getWebpageIndex() {
      return searchIndex$1.getSearchIndex(this.urlInfo);
    }
  }, {
    key: "toJSON",
    value: function toJSON() {
      return {
        urlInfo: this.urlInfo.toJSON(),
        pageIndex: searchIndex$1.getSearchIndex(this.urlInfo),
        title: this.title,
        description: this.description,
        keywords: this.keywords,
        favicon: this.favicon
      };
    }
  }]);

  return WebPageInfo;
}();

module.exports = WebPageInfo$1;

var Webpage = /*#__PURE__*/Object.freeze({
	__proto__: null
});

var WebPageInfo = /*@__PURE__*/getAugmentedNamespace(Webpage);

var sendMessage = communicate.sendMessage;

var onMessage$3 = communicate.onMessage;

var createMessage = communicate.createMessage;







var dbForeground = function () {
  var hub = window.BeenoteEventHub;
  var updateFlag = false;
  hub.on(events$2.SaveNote, function (note, urlInfo) {
    note.urlId = searchIndex$2.getSearchIndex(urlInfo); // setup the index

    var message = createMessage(Message.SaveNote, note);
    message.id = note.noteId;

    if (!updateFlag) {
      var pageInfo = new WebPageInfo();
      message.pageInfo = pageInfo.toJSON();
      message.updatePage = true;
      updateFlag = true;
    }

    sendMessage(message, function (response) {
      if (!response) {
        console.error("Error occurred when saveNote");
      }
    });
  });
  hub.on(events$2.DeleteNote, function (note) {
    updateFlag = false;
    var message = createMessage(Message.RemoveNote, note);
    message.id = note.noteId;
    sendMessage(message, function (response) {
      if (!response) {
        console.error("Error occurred when deleteNote");
      }
    });
  });
  hub.on(events$2.FetchNoteList, function (urlInfo) {
    updateFlag = false;
    var message = createMessage(Message.FetchNoteList, searchIndex$2.getSearchIndex(urlInfo));
    sendMessage(message, function (response) {
      // the response is a list of note JSON.
      if (!response) {
        console.error("Error occurred when fetchNoteList");
      } else {
        hub.emit(events$2.ReceiveNoteList, response);
      }
    });
  });
  /*hub.on("SearchWebPage", (keyStr) => {
      var message = createMessage(messages.SearchWebPage, keyStr);
      sendMessage(message, (result) => {
          console.log(result);
      });
  });*/

  hub.on(events$2.CheckBlackList, function (href) {
    var checkMessage = createMessage(Message.CheckBlackList, href);
    sendMessage(checkMessage, function (response) {
      if (response) {
        hub.emit(events$2.DisablePage, {
          url: href
        });
      } else {
        hub.emit(events$2.EnablePage, {
          url: href
        });
      }
    });
  });
  hub.on(events$2.AddBlackList, function (href) {
    var message = createMessage(Message.AddBlackList, href);
    sendMessage(message, function () {});
  });
  hub.on(events$2.RemoveBlackList, function (href) {
    var message = createMessage(Message.RemoveBlackList, href);
    sendMessage(message, function () {});
  });
  hub.on(events$2.ShareNotePage, function (sharedContent) {
    var message = createMessage(Message.LoadSharedNotes, sharedContent);
    sendMessage(message, function () {});
  });
  hub.on(events$2.GetImageInBackground, function (imageElement, callback_handler, error_handler) {
    var message = createMessage(Message.GetImageInBackground, imageElement);
    sendMessage(message, function (dataURL) {
      //console.log(dataURL);
      if (dataURL) {
        callback_handler(dataURL);
      } else {
        error_handler('LoadImageError');
      }
    });
  });
  hub.on(events$2.FacebookOAuthLogin, function (accesscode) {
    var message = createMessage(Message.FacebookOAuthLogin, accesscode);
    sendMessage(message, function (response) {
      var failureEvent = new Event('beanote-auth-failure');
      var successEvent = new Event('beanote-auth-success');

      if (response) {
        window.dispatchEvent(successEvent);
      } else {
        window.dispatchEvent(failureEvent);
      }
    });
  });
  hub.on(events$2.GoogleOAuthLogin, function (accesscode) {
    var message = createMessage(Message.GoogleOAuthLogin, accesscode);
    sendMessage(message, function (response) {
      var failureEvent = new Event('beanote-auth-failure');
      var successEvent = new Event('beanote-auth-success');

      if (response) {
        window.dispatchEvent(successEvent);
      } else {
        window.dispatchEvent(failureEvent);
      }
    });
  }); // hub.on(events.ReceiveNoteHTMLWord, (filename, noteHtml) => {
  //     var message = createMessage(messages.GenerateExportedWord, noteHtml);
  //     message.filename = filename;
  //     sendMessage(message, () => { });
  // });
  // hub.on(events.ReceiveNoteHTMLEvernote, (filename, noteHtml) => {
  //     var message = createMessage(messages.GenerateExportedEvernote, noteHtml);
  //     message.filename = filename;
  //     sendMessage(message, () => { });
  // });

  onMessage$3(function (request, sender, sendResponse) {
    switch (request.type) {
      case Message.EnablePage:
        if (request.content) {
          hub.emit(events$2.EnablePage, {});
        } else {
          hub.emit(events$2.DisablePage, {});
        }

        break;

      case Message.GetCurrentPageHTMLNotes:
        hub.emit(events$2.FetchPageHTMLNotes, sendResponse);
        break;

      case Message.JumpToNoteInPage:
        var pos = request.content.pos;
        window.scroll({
          top: pos.top - 120,
          left: pos.left,
          behavior: 'smooth'
        });
        break;

      case Message.DeleteNoteExternally:
        hub.emit(events$2.DeleteNoteExternally, request.content);
        break;
    }

    return true;
  }); // check if this page is in black list

  var checkMessage = {
    type: Message.CheckBlackList,
    content: window.location.href
  };
  sendMessage(checkMessage, function (response) {
    if (response) {
      hub.emit(events$2.DisablePage, {});
    }
  });
};

var settings = function () {// console.log(new Error("Not Implemented!!"));
};

/**
 * @param {Object} o1 - old object to be updated
 * @param {Object} o2 - new object
 * @return {Object} updated o1
 */
var objectAssign = function (o1, o2) {
  var onew = {};

  for (var k in o1) {
    onew[k] = o1[k];
  }

  for (var k in o2) {
    onew[k] = o2[k];
  }

  return onew;
};

var events$1 = require('../config/frontend/events');
/**
 * Class create a logger.
 */


var Logger = /*#__PURE__*/function () {
  function Logger() {
    classCallCheck(this, Logger);
  }

  createClass(Logger, [{
    key: "LOG",
    value: function LOG(type) {
      for (var _len = arguments.length, arg = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        arg[_key - 1] = arguments[_key];
      }

      if (arg.length == 1) arg = arg[0];
      window.BeenoteEventHub.emit(events$1[type], arg);
    }
  }, {
    key: "INFO",
    value: function INFO() {
      for (var _len2 = arguments.length, arg = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        arg[_key2] = arguments[_key2];
      }

      this.LOG.apply(this, ['LOG_INFO'].concat(arg));
    }
  }, {
    key: "ERROR",
    value: function ERROR() {
      for (var _len3 = arguments.length, arg = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
        arg[_key3] = arguments[_key3];
      }

      this.LOG.apply(this, ['LOG_ERROR'].concat(arg));
    }
  }, {
    key: "SUCCESS",
    value: function SUCCESS() {
      for (var _len4 = arguments.length, arg = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
        arg[_key4] = arguments[_key4];
      }

      this.LOG.apply(this, ['LOG_SUCCESS'].concat(arg));
    }
  }, {
    key: "WARNING",
    value: function WARNING() {
      for (var _len5 = arguments.length, arg = new Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {
        arg[_key5] = arguments[_key5];
      }

      this.LOG.apply(this, ['LOG_WARNING'].concat(arg));
    }
  }]);

  return Logger;
}();

module.exports = new Logger();

var Logger$1 = /*#__PURE__*/Object.freeze({
	__proto__: null
});

/**
 * Uses canvas.measureText to compute and return the width of the given text of given font in pixels.
 *
 * @param {String} font - The css font descriptor that text is to be rendered with (e.g. "bold 14px verdana").
 * @return {Function}   - measurer, f(text) -> width
 * @see http://stackoverflow.com/questions/118241/calculate-text-width-with-javascript/21015393#21015393
 */
function textRuler$1(font) {
  // re-use canvas object for better performance
  var canvas = textRuler$1.canvas || (textRuler$1.canvas = document.createElement("canvas"));
  var context = canvas.getContext("2d");
  context.font = font;
  return function (text) {
    return context.measureText(text).width;
  };
}

var canvas = {
  textRuler: textRuler$1
};

var logger$2 = /*@__PURE__*/getAugmentedNamespace(Logger$1);

var textRuler = canvas.textRuler;



function boxIntersect(r1, r2) {
  //return !(r2.left > r1.right ||
  //    r2.right < r1.left ||
  //    r2.top > r1.bottom ||
  //    r2.bottom < r1.top);
  //TODO
  throw new Error("not implemented");
}
/**
 * @param {Object} r1 - box A
 * @param {Object} r2 - box B
 * @param {Boolean} true if A contains B.
 */


function boxContains(r1, r2) {
  return r1.top <= r2.top && r1.left <= r2.left && r1.bottom >= r2.bottom && r1.right >= r2.right;
}
/**
 * convert a box into absolute axis, for the ClientRect spec.
 * @param {Object} box
 * @param {Number} box.top
 * @param {Number} box.left
 */


function boxAbsolute$2(box) {
  var b = objectAssign({}, box);
  b.top = b.top + window.pageYOffset;
  b.left = b.left + window.pageXOffset;
  b.bottom = b.bottom + window.pageYOffset;
  b.right = b.right + window.pageXOffset;
  return b;
}
/**
 * check whether a point is inside a box
 */


function isPointInBox(point, box) {
  return box.left < point.x && box.left + box.width > point.x && box.top < point.y && box.top + box.height > point.y;
}
/**
 * Give a list of boxes return from Element.getBoundingBoxes, remove the duplicate one.
 * @param {[Object]} boxes - initial list
 * @return {[Object]} boxes - the list after duplication check.
 */


function resolveBoxDuplication(boxes) {
  var rectList = [];

  for (var i = 0; i < boxes.length; i++) {
    if (boxes[i].width != 0 && boxes[i].height != 0) rectList.push(boxes[i]);
  }

  for (var i = 0; i < rectList.length; i++) {
    var duplicate = false;

    for (var j = 0; j < rectList.length; j++) {
      if (i != j && boxContains(rectList[i], rectList[j])) {
        duplicate = true; // i is duplicate
      }
    }

    if (duplicate) {
      rectList.splice(i, 1);
      i -= 1;
    }
  }

  return rectList;
}
/**
 * Give a list of boxes and the frame of the scroller,
 * @param {[Object]} boxes
 * @param {Object} frame
 * @param {[Object]} boxes, the boxes after crop
 */


function cropBoxWithFrame(boxes, frame) {
  var rectList = [];

  for (var i = 0; i < boxes.length; i++) {
    var box = boxes[i];

    if (box.right <= frame.left || box.left >= frame.right || box.bottom <= frame.top || box.top >= frame.bottom) {
      continue;
    } else {
      var left = Math.max(box.left, frame.left);
      var right = Math.min(box.right, frame.right);
      var top = Math.max(box.top, frame.top);
      var bottom = Math.min(box.bottom, frame.bottom);
      box.left = left;
      box.right = right;
      box.top = top;
      box.bottom = bottom;
      box.width = right - left;
      box.height = bottom - top;
      rectList.push(box);
    }
  }

  return rectList;
}
/**
 * copy rect to a regular object
 * @param  {ClientRect} rect  - rectangle to be copied
 * @return {Object}
 */


function rectCopyToObject$1(rect) {
  return {
    bottom: rect.bottom,
    height: rect.height,
    left: rect.left,
    right: rect.right,
    top: rect.top,
    width: rect.width
  };
}
/**
 * distribute range.textContent among boxes, will add `box.textContent` attribute
 * @param  {Range}  range - the range object
 * @param  {[ClientRect]} boxes - client rects of this range
 * @return {[Object]}
 */


function distributeTextAmongBoxes(range, boxes) {
  // step 1: split text into rough solution
  var allText = range.textContent;
  var ruler = textRuler(range.style.font);
  var _boxes = [];

  for (var i = 0; i < boxes.length; i++) {
    _boxes.push(rectCopyToObject$1(boxes[i]));
  }

  boxes = _boxes;
  var totalWidth = boxes.reduce(function (total, b) {
    return total + b.width;
  }, 0);
  var internalTextWidth = ruler(allText);
  var charList = allText.split("").reverse();
  var charWidthList = charList.map(function (c) {
    return ruler(c);
  });
  Math.min.apply(null, charWidthList);
  boxes.forEach(function (b) {
    b.textPercentage = b.width / totalWidth;
    b.internalWidth = b.textPercentage * internalTextWidth;
    b.useInternalWidth = 0;
    b.charList = [];

    while (b.useInternalWidth + charWidthList[charWidthList.length - 1] * 0.8 <= b.internalWidth) {
      var c = charList.pop();
      var w = charWidthList.pop();
      b.useInternalWidth += w;
      b.charList.push(c);
    }

    b.textContent = b.charList.join(""); // console.log(b.textContent);
  });
  return boxes;
}

var boxRelation = {
  resolveBoxDuplication: resolveBoxDuplication,
  boxIntersect: boxIntersect,
  boxContains: boxContains,
  boxAbsolute: boxAbsolute$2,
  isPointInBox: isPointInBox,
  cropBoxWithFrame: cropBoxWithFrame,
  rectCopyToObject: rectCopyToObject$1,
  distributeTextAmongBoxes: distributeTextAmongBoxes
};

var isMac$1 = navigator.userAgent.indexOf('Mac OS X') != -1;
var platform = {
  isMac: isMac$1
};

var boxAbsolute$1 = boxRelation.boxAbsolute;

var isMac = platform.isMac;

var position = {
  top: 0.0,
  left: 0.0
};
/**
 * set up mouse position listener
 */

window.document.addEventListener('mousemove', function (event) {
  position.top = event.pageY;
  position.left = event.pageX;
}, false);
/**
 * get mouse position
 * @return {Object} position
 * @return {Number} position.top
 * @return {Number} position.left
 */

function mousePosition$1() {
  return objectAssign({}, position);
}
/**
 * @param {DOM} element - Listen user selecting action on all its children
 * nodes.
 * @param {selectionCallback} cb - The callback handles valid user selection.
 * @returns {void}
 */


function setupOnSelection$1(element, cb) {
  element.addEventListener('mouseup', function () {
    /*
      Make sure user select something;
      If so, emit events.UserSelection in pLand;
    */
    setTimeout(function () {
      var sel = window.getSelection();

      if (!(sel.isCollapsed || sel.rangeCount == 0)) {
        cb(sel);
      }
    });
  }, false);
}
/**
 * @param {DOM} element - Listen user selecting action on all its children
 * nodes.
 * @param {selectionCallback} cb - The callback handles valid user selection.
 * @returns {void}
 */

function setupOnResize$1(element, cb) {
  element.addEventListener('resize', cb, false);
}
/**
 * @param {DOM} element - Listen user selecting action on all its children
 * nodes.
 * @param {selectionCallback} cb - The callback handles valid user selection.
 * @returns {void}
 */


function setupObserver$1(element, cb) {
  var observer = new MutationObserver(cb);
  var config = {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['class', 'src', 'style', 'hidden', 'width', 'height']
  };
  observer.observe(element, config);
}
/**
 * @param {DOM} element - Listen user clicking action on all its children nodes.
 * @param {clickCallback} cb
 * @returns {void}
 */


function setupOnMouseDown$1(element, cb) {
  element.addEventListener('mousedown', cb, false);
}
/**
 * @param {DOM} element - Listen user mouse move over all its children nodes.
 * @param {moveCallback} cb
 * @returns {void}
 */


function setupOnMouseMove$1(element, cb) {
  element.addEventListener('mousemove', cb, false);
}
/**
 * @param {DOM} element - Listen user mouse up on all its children nodes.
 * @param {upCallback} cb
 * @returns {void}
 */


function setupOnMouseUp(element, cb) {
  element.addEventListener('mouseup', cb, false);
}

var isSelecting = false;
/**
 * @param {DOM} element - Listen user selecting event(mouse movement) on all its children nodes.
 * @param {Callback} startCb - calling when selecting begins
 * @param {Callback} selectingCb - calling when selecting
 * @returns {void}
 */

function setupOnSelecting$1(element, startCb, selectingCb) {
  var mousedown = false;
  setupOnMouseDown$1(element, function (e) {
    mousedown = true;
    isSelecting = false;
    startCb();
  });
  setupOnMouseMove$1(element, function (e) {
    if (mousedown) {
      // selecting
      var sel = window.getSelection();

      if (sel && !sel.isCollapsed) {
        isSelecting = true;
      }

      selectingCb(sel);
    }
  });
  element.addEventListener('keydown', function (e) {
    if (e.keyCode == 65) {
      // 'a'
      // debugger;
      if (e.ctrlKey && !isMac || e.metaKey && isMac) {
        setTimeout(function () {
          selectingCb(window.getSelection());
        }, 10);
      }
    }
  }, false);
  setupOnMouseUp(element, function (e) {
    mousedown = false;
    isSelecting = false;
  });
}

function userIsSelecting() {
  return isSelecting;
}
/**
 * calculate proper mouse position with selection object
 * @param  {Selection} selection - selection object
 * @return {Object}  {top:Number, left:Number}
 */


function mousePositionWithSelection(selection, offset) {
  if (!selection) return mousePosition$1();
  offset = offset || 0;
  var bbox = selection.getBoundingBox(true),
      bboxes = selection.getClientRects(); //getBoundingBoxes(true);

  var mPos = mousePosition$1();
  var top, left;

  if (mPos.top < bbox.top + offset) {
    // up
    bbox = boxAbsolute$1(bboxes[0]);
    top = mPos.top - offset - 10;
    left = mPos.left;
  } else {
    // down
    bbox = boxAbsolute$1(bboxes[bboxes.length - 1]);
    top = mPos.top + offset - 4;
    left = mPos.left;
  }

  return {
    top: top,
    left: left
  };
}

function positionWithSelection(selection) {
  var type = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'right';
  var offsetTop = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
  var offsetLeft = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;
  if (!selection) return mousePosition$1();

  switch (type) {
    case 'right':
      var bbox = selection.getBoundingBox(true);
      var top = (bbox.bottom + bbox.top) / 2 + offsetTop,
          left = bbox.left + bbox.width + offsetLeft;
      return {
        top: top,
        left: left
      };

    default:
      return mousePosition$1();
  }
}
/**
 * if mPos is in rect
 * @param  {Object} mPos mPos.x, mPos.y
 * @param  {ClientRect} rect {top,right,left,bottom}
 * @return {Boolean}
 */


function mouseInRectViewPort(mPos, rect) {
  return mPos.x > rect.left && mPos.x < rect.left + rect.width && mPos.y > rect.top && mPos.y < rect.top + rect.height;
}

var mouseMovement = {
  setupOnSelection: setupOnSelection$1,
  setupOnMouseDown: setupOnMouseDown$1,
  setupOnMouseMove: setupOnMouseMove$1,
  setupOnMouseUp: setupOnMouseUp,
  setupOnSelecting: setupOnSelecting$1,
  setupObserver: setupObserver$1,
  setupOnResize: setupOnResize$1,
  mousePosition: mousePosition$1,
  mousePositionWithSelection: mousePositionWithSelection,
  positionWithSelection: positionWithSelection,
  mouseInRectViewPort: mouseInRectViewPort,
  userIsSelecting: userIsSelecting
};

function _arrayLikeToArray$1(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

var arrayLikeToArray = _arrayLikeToArray$1;

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return arrayLikeToArray(arr);
}

var arrayWithoutHoles = _arrayWithoutHoles;

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}

var iterableToArray = _iterableToArray;

function _unsupportedIterableToArray$1(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return arrayLikeToArray(o, minLen);
}

var unsupportedIterableToArray = _unsupportedIterableToArray$1;

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

var nonIterableSpread = _nonIterableSpread;

function _toConsumableArray(arr) {
  return arrayWithoutHoles(arr) || iterableToArray(arr) || unsupportedIterableToArray(arr) || nonIterableSpread();
}

var toConsumableArray = _toConsumableArray;

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

var defineProperty = _defineProperty;

function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}

var arrayWithHoles = _arrayWithHoles;

function _iterableToArrayLimit(arr, i) {
  if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return;
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;

  try {
    for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}

var iterableToArrayLimit = _iterableToArrayLimit;

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

var nonIterableRest = _nonIterableRest;

function _slicedToArray(arr, i) {
  return arrayWithHoles(arr) || iterableToArrayLimit(arr, i) || unsupportedIterableToArray(arr, i) || nonIterableRest();
}

var slicedToArray = _slicedToArray;

var XPathCondition = require('../config/frontend').constant.XPathCondition;

var boxAbsolute = require('../_utilities/boxRelation').boxAbsolute;

var rectCopyToObject = require('../_utilities/boxRelation').rectCopyToObject;

var is$1 = require('../_utilities/isType');

require('../_utilities/domMaker').textMaker;

var getComputedAttributes = require('../_utilities/computedStyle').getComputedAttributes;
/**
 * Class contains xpath information for a single DOM elment.
 */


var _XPathElement = /*#__PURE__*/function () {
  /**
   * @param {String|Object} elementName - The tagName of the element | The Jsonify _XPathElement
   * @param {String} className - The className of the element
   * @param {String} idName - The idName of the element
   * @param {Number} order - The order of elment among sublings.
   * @param {String} contentMatcher - The string content used to do regex/wildcard matching
   * @param {Object.<String, String>} otherMeta - Object contains other attribute info attributeName.attributeValue
   */
  function _XPathElement(elementName, className, idName, order, contentMatcher, otherMeta) {
    classCallCheck(this, _XPathElement);

    if (is$1.Object(elementName)) {
      var jsonObject = elementName;

      for (var k in jsonObject) {
        this[k] = jsonObject[k];
      }
    } else {
      this.elementName = elementName || '';
      this.className = className || '';
      this.idName = idName || '';
      this.order = order || -1;
      this.contentMatcher = contentMatcher || '';
      this.otherMeta = otherMeta || {};
    }
  }
  /**
   * @return {Object} Jsonifiable object
   */


  createClass(_XPathElement, [{
    key: "toJSON",
    value: function toJSON() {
      return {
        elementName: this.elementName,
        // className: this.className,
        // idName: this.idName,
        order: this.order // contentMatcher: this.contentMatcher,
        // otherMeta: this.otherMeta

      };
    }
  }]);

  return _XPathElement;
}();
/** Class that contains xpath information of a node
 */


var XPath = /*#__PURE__*/function () {
  /**
   * @param {DOM|Object} elm - HTML Dom Element | JSONify XPath Object
   */
  function XPath(elm) {
    classCallCheck(this, XPath);

    if (elm.constructor == window.Array) {
      this.xPathElementList = elm.map(function (p) {
        return new _XPathElement(p);
      });
    } else if (is$1.String(elm)) {
      var segs = elm.split('/');
      this.xPathElementList = segs.map(function (s) {
        var _s$split = s.split(':'),
            _s$split2 = slicedToArray(_s$split, 2),
            ename = _s$split2[0],
            order = _s$split2[1];

        return new _XPathElement(ename, null, null, parseInt(order));
      });
    } else {
      this.xPathElementList = [];

      if (!is$1.HtmlNode(elm)) {
        // text, order
        var order = 1,
            sib = elm;

        while (sib = sib.previousSibling) {
          if (sib.nodeType == elm.nodeType) order++;
        }

        var element = new _XPathElement(elm.constructor.name.toLowerCase() + "()", '', '', order);
        this.xPathElementList.unshift(element);
        elm = elm.parentNode;
      }

      for (; elm && elm.nodeType == 1; elm = elm.parentNode) {
        var elementName = '',
            className = '',
            idName = '',
            order = -1,
            contentMatcher = '',
            otherMeta = {};
        elementName = elm.localName.toLowerCase();
        if (elm.hasAttribute('id')) idName = elm.getAttribute('id');
        if (elm.hasAttribute('class')) className = elm.getAttribute('class');
        order = 1;

        for (var sib = elm.previousSibling; sib; sib = sib.previousSibling) {
          if (sib.localName == elm.localName) order++;
        }

        var element = new _XPathElement(elementName, className, idName, order, contentMatcher, otherMeta);
        this.xPathElementList.unshift(element);
      }
    }
  }
  /**
   * @returns {String} - XPath
   */


  createClass(XPath, [{
    key: "toString",
    value: function toString() {
      var segs = this.xPathElementList.map(function (p) {
        return "".concat(p.elementName, "[").concat(p.order, "]");
      });
      var xpath = '/' + segs.join('/');
      return segs.length ? xpath : null;
    }
  }, {
    key: "toStorageString",
    value: function toStorageString() {
      var segs = this.xPathElementList.map(function (p) {
        return "".concat(p.elementName, ":").concat(p.order);
      });
      return segs.join('/');
    }
    /**
     * @param {Number|String} condition - conditionally generate xpaths | xpath string to eval;
     * @returns {DOM}
     */

  }, {
    key: "evalToElement",
    value: function evalToElement(condition) {
      // TODO: need to be changed back to normal
      var str = is$1.String(condition) ? condition : this.toString(condition);
      var evaluator = new XPathEvaluator();
      var result = evaluator.evaluate(str, document.documentElement, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
      return result.singleNodeValue;
    }
    /**
     * @return {Object} Jsonifiable object
     */

  }, {
    key: "toJSON",
    value: function toJSON() {
      return this.xPathElementList.map(function (p) {
        return p.toJSON();
      });
    }
  }]);

  return XPath;
}();
/**
 * Class that contains information of a selection.
 */


var Selection$1 = /*#__PURE__*/function () {
  /**
   * @param {Range|Object} nativeRange - Native Window Range Object | JSONify Selection Object
   */
  function Selection(nativeRange) {
    classCallCheck(this, Selection);

    if (is$1.Range(nativeRange)) {
      var r = this._nativeRange = nativeRange;
      this.startOffset = r.startOffset;
      this.endOffset = r.endOffset;
      this.startContainer = new XPath(r.startContainer);
      this.endContainer = new XPath(r.endContainer);
    } else {
      var r = nativeRange;
      this.startOffset = r.startOffset;
      this.endOffset = r.endOffset;
      this.startContainer = new XPath(r.startContainer);
      this.endContainer = new XPath(r.endContainer);
      this._nativeRange = document.createRange();
      var startNode = this.startContainer.evalToElement(XPathCondition.TAG_NAME_ONLY);
      var endNode = this.endContainer.evalToElement(XPathCondition.TAG_NAME_ONLY);

      if (startNode && endNode) {
        // only create range when xpath is valid
        if (is$1.TextNode(startNode) && this.startOffset >= startNode.textContent.length) {
          // the text in the original web page has changed
          // we can not render the note anymore.
          return;
        } else {
          this._nativeRange.setStart(startNode, this.startOffset);
        }

        if (is$1.TextNode(endNode) && this.endOffset > endNode.textContent.length) {
          this._nativeRange.setEnd(endNode, endNode.textContent.length);
        } else {
          this._nativeRange.setEnd(endNode, this.endOffset);
        } //this._nativeRange.setStart(startNode, this.startOffset);
        //this._nativeRange.setEnd(endNode, this.endOffset);

      }
    }
  }

  createClass(Selection, [{
    key: "reEvaluateRange",
    value: function reEvaluateRange() {
      this._nativeRange = document.createRange();
      var startNode = this.startContainer.evalToElement(XPathCondition.TAG_NAME_ONLY);
      var endNode = this.endContainer.evalToElement(XPathCondition.TAG_NAME_ONLY);

      if (startNode && endNode) {
        // only create range when xpath is valid
        if (is$1.TextNode(startNode) && this.startOffset >= startNode.textContent.length) {
          // the text in the original web page has changed
          // we can not render the note anymore.
          return;
        } else {
          this._nativeRange.setStart(startNode, this.startOffset);
        }

        if (is$1.TextNode(endNode) && this.endOffset > endNode.textContent.length) {
          this._nativeRange.setEnd(endNode, endNode.textContent.length);
        } else {
          this._nativeRange.setEnd(endNode, this.endOffset);
        } //this._nativeRange.setStart(startNode, this.startOffset);
        //this._nativeRange.setEnd(endNode, this.endOffset);

      }
    }
    /**
     * get all elements the selection contains
     * @return {Range[]}
     */

  }, {
    key: "getRangeList",
    value: function getRangeList() {
      function filter(node) {
        if (is$1.TextNode(node)) // we only accept text node and image node
          return NodeFilter.FILTER_ACCEPT;
        if (is$1.ImageNode(node)) return NodeFilter.FILTER_ACCEPT;
        return NodeFilter.FILTER_REJECT;
      }

      if (this._nativeRange.collapsed) return [];
      var iterator = RangeIterator(this._nativeRange, NodeFilter.SHOW_ALL, filter);
      var rangeList = [];
      var node = undefined;

      while (node = iterator.nextNode()) {
        if (!node.parentElement.offsetParent) // filter invisible element
          continue;
        var range = new Range();

        if (is$1.ImageNode(node)) {
          range.selectNode(node);
        } else {
          range.selectNodeContents(node);
        }

        if (this._nativeRange.compareBoundaryPoints(Range.START_TO_END, range) < 0) continue;
        if (node == this._nativeRange.startContainer) range.setStart(node, this._nativeRange.startOffset);
        if (node == this._nativeRange.endContainer) range.setEnd(node, this._nativeRange.endOffset);
        var boxes = this.getClientRectsWithoutLineBreak(range);

        if (boxes.length > 0) {
          // filter the empty range.
          if (is$1.TextNode(node)) {
            var attrs = getComputedAttributes(node.parentNode, ['whiteSpace']);
            var preRangeList = [];

            if (attrs.whiteSpace == "pre") {
              // deal with pre new line
              var s = range.toString();

              if (s.indexOf('\n') == -1) {
                // pre but only one line
                preRangeList.push(range);
              } else {
                // pre and multiple line
                var strList = s.split('\n');
                var NEW_LINE_LEN = 1;
                var startOffset = range.startOffset;

                for (var i = 0; i < strList.length; i++) {
                  var preRange = document.createRange();
                  preRange.setStart(node, startOffset);
                  var endOffset = startOffset + strList[i].length;
                  preRange.setEnd(node, endOffset);
                  startOffset = endOffset + NEW_LINE_LEN;
                  preRangeList.push(preRange);
                }
              }
            } else {
              preRangeList.push(range);
            }

            preRangeList.forEach(function (r) {
              rangeList.push(r);
            });
          } else {
            rangeList.push(range);
          }
        }
      }

      return rangeList;
    }
  }, {
    key: "getClientRectsWithoutLineBreak",
    value: function getClientRectsWithoutLineBreak(range) {
      // this function is used to handle different ClientRects result in HMTL text line change
      var resultList = toConsumableArray(range.getClientRects());

      var newRange = range.cloneRange();
      newRange.setEnd(newRange.startContainer, newRange.startOffset);

      var collapsedCount = toConsumableArray(newRange.getClientRects()).filter(function (a) {
        return a.width * a.height > 0;
      }).length;

      if (collapsedCount > 1) resultList.shift();
      return resultList;
    }
    /**
     * Distribute the text content into boxes generated by a range
     * This function is recursive function, the the boxes will be assigned on by one
     * @param{Node} node - HTML node element, in this case it is a text node
     * @param{Range} range - HTML range element, corresponding to target range
     * @param{Integer} textStart - range start offset
     * @param{Integer} textEnd - range end offset
     * @param{[String]} resultList - a string array, store the final result.
     */

  }, {
    key: "distributeText",
    value: function distributeText(node, range, textStart, textEnd, resultList) {
      var boxes = this.getClientRectsWithoutLineBreak(range); //range.getClientRects();

      if (boxes.length == 1) {
        resultList.push(node.textContent.substr(textStart, textEnd - textStart));
        return;
      } else {
        var tmpStart = textStart,
            tmpEnd = textEnd;
        var newRange = new Range();
        newRange.selectNodeContents(node);
        newRange.setStart(node, textStart);
        var iteration = 0;
        var textSplit = parseInt((textStart + textEnd) / 2); // core logic: split an range into several boxes with text

        while (iteration < 50) {
          newRange.setEnd(node, textSplit);
          var boxList1 = this.getClientRectsWithoutLineBreak(newRange); //newRange.getClientRects();

          newRange.setEnd(node, textSplit + 1);
          var boxList2 = this.getClientRectsWithoutLineBreak(newRange); //newRange.getClientRects();

          if (boxList1.length > 1) {
            // the cut is too big
            tmpEnd = textSplit;
            textSplit = parseInt((tmpStart + tmpEnd) / 2);
          } else if (boxList2.length > 1) {
            // boxList1.length == 1 && boxList2.length > 1
            var textSplitEndPoint = boxList2[1].width * boxList2[1].height > 0 ? textSplit : textSplit + 1;
            resultList.push(node.textContent.substr(textStart, textSplitEndPoint - textStart));
            range.setStart(node, textSplitEndPoint);
            this.distributeText(node, range, textSplitEndPoint, textEnd, resultList);
            return;
          } else {
            // the cut is too short
            tmpStart = textSplit;
            textSplit = parseInt((tmpStart + tmpEnd) / 2);
          }

          iteration += 1;
        }
      }
    }
    /**
     * static method, clear the selection in the current webpage.
     */

  }, {
    key: "getBoundingBoxes",
    value:
    /**
     * @param {Boolean} cached - use cached or not
     * @returns {ClientRect.<String,Number>[]}
     * @returns ClientRect.top
     * @returns ClientRect.bottom
     * @returns ClientRect.left
     * @returns ClientRect.right
     * @returns ClientRect.width
     * @returns ClientRect.height
     */
    function getBoundingBoxes(rangeList) {
      var _this = this;

      rangeList.forEach(function (range) {
        var node = range.startContainer;

        if (is$1.TextNode(node)) {
          var resultList = [];

          _this.distributeText(node, range.cloneRange(), range.startOffset, range.endOffset, resultList);

          range.textContent = resultList;
          var parentElement = range.startContainer.parentElement;
          var style = getComputedAttributes(parentElement, Selection.TextStyleList);
          style["textIndent"] = "initial";
          range.style = style;
        }
      });
      var boundingList = [];

      for (var i = 0; i < rangeList.length; i++) {
        var range = rangeList[i];
        var boxes = this.getClientRectsWithoutLineBreak(range); //range.getClientRects()

        if (range.textContent) {
          // this is a text node
          for (var j = 0; j < boxes.length; j++) {
            var box = rectCopyToObject(boxes[j]);
            box.textContent = range.textContent[j];
            box.style = range.style;
            box.range = range;
            boundingList.push(box);
          }
        } else {
          // this is an image node
          console.assert(boxes.length == 1);

          var _box = rectCopyToObject(boxes[0]);

          _box.textContent = null;
          _box.style = {
            'width': _box.width + 'px'
          }; // set width information for image

          _box.range = range;
          boundingList.push(_box);
        }
      }

      return boundingList;
    }
    /**
     * A wrapper function for Range.getClientRects()
     * @return {ClientRectList}
     */

  }, {
    key: "getClientRects",
    value: function getClientRects() {
      this.reEvaluateRange();
      return this._nativeRange.getClientRects();
    }
    /**
     * @param {Boolean} absolute - absolute or viewport
     * @return {ClientRect}
     */

  }, {
    key: "getBoundingBox",
    value: function getBoundingBox(absolute) {
      var x = this._nativeRange.getBoundingClientRect();

      return absolute ? boxAbsolute(x) : x;
    }
    /**
     * @return {Object} Jsonifiable object
     */

  }, {
    key: "toJSON",
    value: function toJSON() {
      return {
        startOffset: this.startOffset,
        endOffset: this.endOffset,
        // startContainer: this.startContainer.toJSON(),
        // endContainer: this.endContainer.toJSON()
        startContainer: this.startContainer.toStorageString(),
        endContainer: this.endContainer.toStorageString()
      };
    }
  }, {
    key: "toString",
    value: function toString() {
      var str = this._nativeRange.toString();

      return str.split('\n').filter(function (x) {
        if (!x) return true;else return x.trim();
      }).join('\n'); //replace consecutive blanklines with a single newline
    }
  }, {
    key: "position",
    get:
    /**
     * @return {number} - return distance between top and start of this selection
     */
    function get() {
      var rect = this.getBoundingBox(true);
      return {
        top: rect.top,
        left: rect.left,
        bottom: rect.bottom,
        right: rect.right
      };
    }
  }], [{
    key: "clearSelection",
    value: function clearSelection() {
      if (window.getSelection()) {
        window.getSelection().removeAllRanges();
      } else if (document.selection) {
        document.selection.empty();
      }
    }
  }, {
    key: "serializeRange",
    value: function serializeRange(range) {
      return {
        startContainer: range.startContainer,
        endContainer: range.endContainer,
        startOffset: range.startOffset,
        endOffset: range.endOffset
      };
    }
  }, {
    key: "deserializeRange",
    value: function deserializeRange(range) {
      var nrange = document.createRange();
      nrange.setStart(range.startContainer, range.startOffset);
      nrange.setEnd(range.endContainer, range.endOffset);
      return nrange;
    }
  }]);

  return Selection;
}();
/**
 * Returns an ES6 Iterator that traverses between the start and end points
 * of a `Range` instance.
 *
 * @param {Range} range - Range instance to iterator over selected Nodes
 * @param {Number} [whatToShow] - Bitwise OR'd list of Filter specification constants from the NodeFilter DOM interface
 * @param {NodeFilter} [filter] - An object implementing the NodeFilter interface
 * @param {Boolean} [entityReferenceExpansion] - A flag that specifies whether entity reference nodes are expanded
 * @public
 */


defineProperty(Selection$1, "TextStyleList", ["font", "fontWeight", "color", "direction", "textTransform", "textAlign", "textDecoration", "textOrientation", "textShadow", "textRendering", "letterSpacing", "wordSpacing", "writingMode", "verticalAlign", "transform", "zIndex", "whiteSpace"]);

function RangeIterator(range, whatToShow, filter) {
  if (!range) throw new TypeError('a Range instance must be given');
  var r = range;
  r.startContainer;
  r.endContainer;
  var start = r.commonAncestorContainer;
  var doc = start.ownerDocument;
  r = null;

  function acceptNode(node) {
    if (!withinRange(node)) return NodeFilter.FILTER_REJECT;
    if (!filter) return NodeFilter.FILTER_ACCEPT;
    return filter(node);
  }

  function withinRange(node) {
    return range.intersectsNode(node); // This API is only supported in Chrome and FireFox

    /*if (node === startContainer || node === endContainer) return true;
    let s = node.compareDocumentPosition(startContainer);
    let e = node.compareDocumentPosition(endContainer);
    return (
        (s & Node.DOCUMENT_POSITION_PRECEDING || s & Node.DOCUMENT_POSITION_CONTAINS) &&
        (e & Node.DOCUMENT_POSITION_FOLLOWING || e & Node.DOCUMENT_POSITION_CONTAINS)
    );*/
  }

  return doc.createNodeIterator(start, whatToShow, acceptNode);
}

module.exports = {
  Selection: Selection$1,
  XPath: XPath
};

var Selection$2 = /*#__PURE__*/Object.freeze({
	__proto__: null
});

var mousePosition = mouseMovement.mousePosition;
/**
 * Receive message from background, function for chrome.
 * @param{requestCallback} callback - the callback function that handle the reply
 */


function chromeOnMessage(callback) {
  chrome.runtime.onMessage.addListener(function (req, sender, res) {
    return callback(req, sender, res);
  });
}
/**
 * Generic receive message function, will support other browser later.
 * @param{requestCallback} callback - the callback function that handle the reply
 */


function onMessage$2(callback) {
  // browser.chrome
  return chromeOnMessage(callback);
}

var rightClickPosition = {
  top: 0,
  left: 0
};

function contextMenuHandler(request, sender, response) {
  //window.BeenoteEventHub.emit(events.DisablePage, {});
  if (request.type == events$2.ContextMenuClick) {
    logger$2.INFO("context menu click");
    window.BeenoteEventHub.emit(events$2.ContextMenuClick, {
      menuId: request.menuId,
      position: rightClickPosition,
      content: request.content
    });
  }
}

function saveRightClickPosition$1(mouseEvent) {
  if (mouseEvent.which == 3 || mouseEvent.ctrlKey && mouseEvent.which == 1) {
    // ignore isMac
    var pos = mousePosition();
    logger$2.INFO("Write click at <".concat(pos.top, ",").concat(pos.left, ">"));
    rightClickPosition.top = pos.top;
    rightClickPosition.left = pos.left;
  }
}

var menuListener = {
  setupMenuListener: function setupMenuListener() {
    return onMessage$2(contextMenuHandler);
  },
  saveRightClickPosition: saveRightClickPosition$1
};

var trimRight = require('../../_utilities/trim').trimRight;
/**
 * add _{mode} suffix to rest api path 
 * @param {{path: string, requestType: string}[]} lambdaConfig 
 * @param {'prod' | 'test' | 'dev'} mode 
 * @param {string} version
 */


function transformLambdaConfig(lambdaConfig, mode, version) {
  var result = {};
  Object.entries(lambdaConfig).forEach(function (_ref) {
    var _ref2 = slicedToArray(_ref, 2),
        key = _ref2[0],
        value = _ref2[1];

    var newPath = trimRight(value.path, '/');

    if (mode != 'prod') {
      newPath += '_' + mode;
    }

    if (version) {
      newPath = '/' + version + newPath;
    }

    var newValue = Object.assign({}, value, {
      path: newPath
    });
    result[key] = newValue;
  });
  return result;
}

module.exports = {
  transformLambdaConfig: transformLambdaConfig,
  version: "v1",
  lambda: {
    // add rest api setup for each lambda funciton here
    UserRegister: {
      requestType: 'RegisterUser',
      path: "/registeruser"
    },
    UserVerification: {
      requestType: 'UserVerification',
      path: "/verifyuser"
    },
    UserLogin: {
      requestType: 'UserLogin',
      path: '/userlogin'
    },
    UserFacebookLogin: {
      requestType: 'FacebookLogin',
      path: '/facebooklogin'
    },
    UserGoogleLogin: {
      requestType: 'GoogleLogin',
      path: '/googlelogin'
    },
    UserInfoUpdate: {
      requestType: 'UserInfoUpdate',
      path: '/userinfo'
    },
    UserForgetPassword: {
      requestType: 'ForgetPassword',
      path: '/forgetpassword'
    },
    UserChangePassword: {
      requestType: 'ChangePassword',
      path: '/changepassword'
    }
  }
};

var rpc$1 = /*#__PURE__*/Object.freeze({
	__proto__: null
});

var rpc = /*@__PURE__*/getAugmentedNamespace(rpc$1);

var mode = 'prod';

if (process.env.NODE_ENV == 'development') {
  mode = 'dev';
} else if (process.env.NODE_ENV == 'testing') {
  mode = 'test';
}

var config = {
  // the rest api depends on which mode we use
  api: rpc.transformLambdaConfig(rpc.lambda, mode, rpc.version),
  endpoint: 'api.beanote.com',
  facebook_oauth: {
    APP_ID: '4623024267770169',
    redirect_uri: 'https://oauth.beanote.com/oauth/v1/facebook',
    redirect_path: "/oauth/v1/facebook",
    oauth_uri: 'https://www.facebook.com/v9.0/dialog/oauth'
  },
  google_oauth: {
    CLIENT_ID: '690733066011-8u2km0mudvlcojfjqoulhdrkhqmn22k6.apps.googleusercontent.com',
    redirect_uri: 'https://oauth.beanote.com/oauth/v1/google',
    redirect_path: "/oauth/v1/google",
    oauth_uri: 'https://accounts.google.com/o/oauth2/v2/auth',
    access_scope: ['https://www.googleapis.com/auth/userinfo.email', 'https://www.googleapis.com/auth/userinfo.profile'].join(' ')
  },
  aws_backend: {
    region: 'us-east-1',
    table: {
      revisionRecord: "BeanoteRevisionRecord",
      noteDataStore: "BeanoteNoteDataStore"
    },
    identityPoolId: 'us-east-1:dab13ad8-6aa0-4963-a2d0-c977e5efe040',
    identityRoleArn: "arn:aws:iam::317624286696:role/Beanote_App_Auth_Role",
    tokenDuration: 72000
  },
  KEY_EMAIL: 'BEANOTE_CACHE_EMAIL',
  // KEY_DB_APIKEY: 'BEANOTE_CACHE_DB_APIKEY',
  // KEY_DB_PASSWORD: 'BEANOTE_CACHE_DB_PASSWORD',
  // KEY_DB_HOST: 'BEANOTE_CACHE_DB_HOST',
  KEY_NAME: 'BEANOTE_CACHE_NAME',
  KEY_AVATAR: 'BEANOTE_CACHE_DB_AVATAR',
  KEY_USER_ID: 'BEANOTE_USER_ID',
  KEY_TOKEN_ID: 'BEANOTE_TOKEN_ID',
  KEY_COOKIE: 'BEANOTE_COOKIE',
  KEY_CREDENTIAL: 'BEANOTE_CREDENTIAL',
  KEY_TOKEN_REFRESH_TIMEOUT: 'BEANOTE_TOKEN_REFRESH_TIMEOUT',
  KEY_CURRENT_REV: 'BEANOTE_CURRENT_REVISION',
  KEY_SYNC_STATUS: "BEANOTE_DB_SYNC_STATUS",
  KEY_USER_INITIAL_SYNCING_MAP: 'BEANOTE_USER_INITIAL_SYNCING_MAP',
  sync: {
    modificationInterval: 60 * 1000,
    pollingInterval: 60 * 1000 * 10 // per 10 minute

  },
  dbSyncStatus: {
    syncFinished: "yes",
    syncStopped: "no",
    syncFailed: "failed",
    syncOngoing: "loading"
  }
};
var backend = config;

var require$$1$2 = /*@__PURE__*/getAugmentedNamespace(Selection$2);

var setupOnSelection = mouseMovement.setupOnSelection;

var setupOnSelecting = mouseMovement.setupOnSelecting;

var setupOnMouseDown = mouseMovement.setupOnMouseDown;

var setupOnMouseMove = mouseMovement.setupOnMouseMove;

var setupOnResize = mouseMovement.setupOnResize;

var setupObserver = mouseMovement.setupObserver; // var setupUrlObserver = require('./urlObserver').setupUrlObserver




var Selection = require$$1$2.Selection;

var setupMenuListener = menuListener.setupMenuListener;

var saveRightClickPosition = menuListener.saveRightClickPosition;



var uiListener = function () {
  var hub = window.BeenoteEventHub;
  setupOnSelection(document.body, function (sel) {
    var sel = new Selection(sel.getRangeAt(0));
    hub.emit(events$2.UserSelection, sel);
  });
  setupOnMouseDown(window
  /*document.body*/
  , function (event) {
    saveRightClickPosition(event);
    hub.emit(events$2.UserMouseDown, event);
  });
  setupOnSelecting(document.body, function () {
    hub.emit(events$2.UserSelecting, null);
  }, function (sel) {
    hub.emit(events$2.UserSelecting, sel);
  });
  setupOnResize(window, function (event) {
    hub.emit(events$2.WindowResize, {});
  });
  var rightTop = {
    value: false
  };
  setupOnMouseMove(window, function (event) {
    var x = event.screenX;
    var y = event.screenY;
    var X = window.innerWidth;
    var Y = window.innerHeight;
    var rx = event.screenX / window.innerWidth;
    var ry = event.screenY / window.innerHeight;

    if (rx > 0.8 && ry < 0.3 || X - x < 100 && Y - y < 100) {
      if (!rightTop.value) {
        hub.emit(events$2.UserEnterRightTop, null);
        rightTop.value = true;
      }
    } else {
      if (rightTop.value) {
        hub.emit(events$2.UserLeaveRightTop, null);
        rightTop.value = false;
      }
    }
  });
  setupObserver(document.body, function (event) {
    hub.emit(events$2.PageChanged, event);
  });
  setupMenuListener(); // Check if the url is beanote specific url

  var BEANOTE_HOSTNAME = "oauth.beanote.com";

  if (window.location.hostname == BEANOTE_HOSTNAME) {
    var GOOGLE_CODE = 'code';
    var FACEBOOK_CODE = 'code';
    var failureEvent = new Event('beanote-auth-failure');

    if (window.location.pathname.startsWith(backend.facebook_oauth.redirect_path)) {
      var param = new URLSearchParams(window.location.search);
      var accesscode = param.get(FACEBOOK_CODE);

      if (accesscode) {
        hub.emit(events$2.FacebookOAuthLogin, accesscode);
      } else {
        window.dispatchEvent(failureEvent);
      }
    }

    if (window.location.pathname.startsWith(backend.google_oauth.redirect_path)) {
      var param = new URLSearchParams(window.location.search);
      var accesscode = param.get(GOOGLE_CODE);

      if (accesscode) {
        hub.emit(events$2.GoogleOAuthLogin, accesscode);
      } else {
        window.dispatchEvent(failureEvent);
      }
    }
  }
};

var uiNotification = function () {// hub.emit(events.Alert, "uiNotification");
  // console.log(new Error("Not Implemented!!"));
};

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

var asyncToGenerator = _asyncToGenerator;

var regenerator = runtime_1;

var Layer = require('./Layer').Layer;
    require('./Layer').connectHighlightAndSticker;
    var events = require('../config/frontend/events'),
    logger$1 = require('../_utilities/Logger'),
    uuid = require('../_utilities/UUID'),
    UrlInfo = require('./UrlInfo'),
    //Tooltip = require('./tooltip').Tooltip,
tooltip = require('./tooltip')["default"],
    highlightColorTooltip = require('./tooltip').highlightColorTooltip,
    highlightColorStyleSheet = require('./tooltip').highlightColorStyleSheet,
    highlightTooltip = require('./tooltip').highlightTooltip,
    tooltipType = require('./tooltip').type,
    nType = require('./Note').type,
    Sticker = require('./Sticker'),
    clearSelection = require('../uiListener/Selection').Selection.clearSelection,
    updateStickyElements = require('../_utilities/domMaker').updateStickyElements; // getHighlightXHTML = require('./htmlClip').getHighlightXHTML,


var createWordExport$1 = require('../dbBackground/export/wordExport').createWordExport; //    createEvernoteExport = require('./evernoteExport').createEvernoteExport;


var http = require('../_utilities/http');

var AnalyticsLogger$3 = require('../dbForeground/analytics');

var alogger = new AnalyticsLogger$3('uiRender/index');

require('./bookmark');

module.exports = function () {
  var selfLocation = {
    value: new UrlInfo(window.location)
  };
  var hub = window.BeenoteEventHub;
  var layer = new Layer(uuid());
  var updateTimer = null; // TODO: Code it Later
  // var bookmark = new Bookmark()
  // bookmark.addTo(layer)

  tooltip.addTo(layer);
  highlightTooltip.addTo(layer, false);
  highlightColorTooltip.addTo(layer, false);
  layer.tooltip = tooltip;
  layer.highlightTooltip = highlightTooltip;
  layer.highlightColorTooltip = highlightColorTooltip;
  layer.add(highlightColorStyleSheet);
  layer.highlightColorStyleSheet = highlightColorStyleSheet;
  Sticker.addStyleTo(layer);
  hub.on(events.DisablePage, function (event) {
    layer.disable();
  }).on(events.EnablePage, function (event) {
    layer.enable();
  }).on(events.UserSelection, function (selection) {
    return layer.showTooltip(selection);
  }).on(events.UserMouseDown, function (event) {
    layer.hideTooltipIfLossFocus(event);
    layer.handleNoteClick(event);
  }).on(events.UserSelecting, function (sel) {
    layer.adjustHighlightColorFromSelection(sel);

    if (sel && !sel.isCollapsed && layer.focusedNote && layer.focusedNote.noteType == nType.Highlight) {
      layer.setFocusedNote(null);
    }
  })
  /**
   * events.TooltipClick callback
   * @param {Array} - [type, selection, clickEvent]
   */
  .on(events.TooltipClick, /*#__PURE__*/function () {
    var _ref = asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee(type, selection, mouseEvent) {
      var notes;
      return regenerator.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              clearSelection(); // clear selection when the tooltip is clicked.

              if (!(type == tooltipType.Google)) {
                _context.next = 3;
                break;
              }

              return _context.abrupt("return");

            case 3:
              _context.next = 5;
              return layer.createAndRenderNote(type, selection);

            case 5:
              notes = _context.sent;
              notes.forEach(function (note) {
                // @comment: better put into Highlight class using async/await
                // if (note.noteType == nType.Highlight) {
                //     var pElement = getHighlightXHTML(note);
                //     pElement.then((root_element) => {
                //         note.contextHTMLClip = root_element.outerHTML;
                //         hub.emit(events.SaveNote, [note.toJSON(), window.location], true);
                //     }).catch((err) => hub.emit(events.SaveNote, [note.toJSON(), window.location], true));
                // } else {
                hub.emit(events.SaveNote, [note.toJSON(), window.location], true); // }
              });

            case 7:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function (_x, _x2, _x3) {
      return _ref.apply(this, arguments);
    };
  }()).on(events.ContextMenuClick, /*#__PURE__*/function () {
    var _ref2 = asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee2(menuItem) {
      var notes;
      return regenerator.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              notes = [];

              if (!(menuItem.menuId == 'StickerNote')) {
                _context2.next = 7;
                break;
              }

              _context2.next = 4;
              return layer.createAndRenderNote(nType.Sticker, menuItem.position);

            case 4:
              notes = _context2.sent;
              _context2.next = 11;
              break;

            case 7:
              if (!(menuItem.menuId == 'RectangleNote')) {
                _context2.next = 11;
                break;
              }

              _context2.next = 10;
              return layer.createAndRenderNote(nType.Rectangle, menuItem.position);

            case 10:
              notes = _context2.sent;

            case 11:
              notes.forEach(function (note) {
                return hub.emit(events.SaveNote, [note.toJSON(), window.location], true);
              });

            case 12:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));

    return function (_x4) {
      return _ref2.apply(this, arguments);
    };
  }()).on(events.CommentOnHighlight, /*#__PURE__*/function () {
    var _ref3 = asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee3(highlight) {
      var notes, sticker;
      return regenerator.wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              _context3.next = 2;
              return layer.createAndRenderNote(nType.StickerBelongToHighlight, highlight);

            case 2:
              notes = _context3.sent;
              sticker = notes[0];
              hub.emit(events.SaveNote, [highlight.toJSON(), window.location], true);
              hub.emit(events.SaveNote, [sticker.toJSON(), window.location], true);

            case 6:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3);
    }));

    return function (_x5) {
      return _ref3.apply(this, arguments);
    };
  }()).on(events.ReceiveNoteList, /*#__PURE__*/function () {
    var _ref4 = asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee4(jsonlist) {
      var notes, failedNoteList;
      return regenerator.wrap(function _callee4$(_context4) {
        while (1) {
          switch (_context4.prev = _context4.next) {
            case 0:
              if (!layer.isEnabled) {
                _context4.next = 8;
                break;
              }

              _context4.next = 3;
              return layer.deserializeNotes(jsonlist);

            case 3:
              notes = _context4.sent;
              layer.renderNotes(notes);
              notes.forEach(function (n) {
                // COMMENT: need testing
                if (n.needMigration()) {
                  hub.emit(events.SaveNote, [n.toJSON(), window.location], true);
                }
              });
              failedNoteList = notes.filter(function (n) {
                return !n.isRendered;
              }).map(function (note) {
                if (note._selection) {
                  return {
                    noteType: 'Highlight',
                    startContainer: note._selection.startContainer.toString(),
                    endContainer: note._selection.endContainer.toString(),
                    startOffset: note._selection.startOffset,
                    endOffset: note._selection.endOffset
                  };
                } else {
                  return note.toJSON();
                }
              });

              if (failedNoteList.length > 0) {
                // NOTE: this branch is sometimes executed when the page is not fully loaded and produce false alarm
                alogger.warn({
                  event: 'RenderFailed',
                  notes: failedNoteList,
                  url: window.location.href
                });
              }

            case 8:
            case "end":
              return _context4.stop();
          }
        }
      }, _callee4);
    }));

    return function (_x6) {
      return _ref4.apply(this, arguments);
    };
  }()).on(events.WindowResize, function () {
    layer.renderAllNotes();
  }).on(events.FetchPageHTMLNotes, function (callback) {
    var notelist = layer.getCurrentPageHTMLNotes();
    callback(notelist);
  }).on(events.PageChanged, function (mutation) {
    var newLocation = new UrlInfo(window.location);

    if (!newLocation.isSameUrl(selfLocation.value)) {
      logger$1.INFO("Url changed"); // update location and remove all current note.

      selfLocation.value = newLocation;
      layer.cleanupLayer(); // fetch note list for this new url

      window.setTimeout(function () {
        hub.emit(events.FetchNoteList, window.location);
        hub.emit(events.CheckBlackList, window.location.href);
      }, 1000);
    } else {
      if (!updateTimer) {
        updateTimer = window.setTimeout(function () {
          layer.renderUnrenderedNotes();
          updateTimer = null;
        }, 300);
      }
    }
  }).on(events.GetNoteHTMLWordDebug, /*#__PURE__*/asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee5() {
    var noteList, result;
    return regenerator.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            noteList = [];
            layer.iterateOverAllNotes(function (note) {
              return noteList.push(note);
            });
            noteList.sort(function (a, b) {
              return a.position.top > b.position.top ? 1 : -1;
            });
            _context5.next = 5;
            return createWordExport$1(noteList);

          case 5:
            result = _context5.sent;
            http.downloadTextAsFile('exported.html', result);

          case 7:
          case "end":
            return _context5.stop();
        }
      }
    }, _callee5);
  }))).on(events.DeleteNoteExternally, function (jsonNote) {
    var typeIdTupleList = [[jsonNote.noteType, jsonNote.noteId]];

    if (jsonNote.refHighlight) {
      typeIdTupleList.push([jsonNote.refHighlight.noteType, jsonNote.refHighlight.noteId]);
    }

    typeIdTupleList.forEach(function (_ref6) {
      var _ref7 = slicedToArray(_ref6, 2),
          tp = _ref7[0],
          nid = _ref7[1];

      var note = layer.noteMap[tp][nid];

      if (note) {
        note.isDeleted = true;
        layer.removeNoteFromDom(note);
        delete layer.noteMap[tp][nid];
        hub.emit(events.DeleteNote, note.toJSON());
      }
    });
  }); // TODO: Code it Later
  // .on(events.UserEnterRightTop, () => {
  //     if (layer.isEnabled) {
  //         bookmark.show()
  //     }
  // })
  // .on(events.UserLeaveRightTop, () => {
  //     if (layer.isEnabled) {
  //         bookmark.hide()
  //     }
  // })

  hub.emit(events.FetchNoteList, window.location);
  updateStickyElements(document.body, 2); // TODO
  // emit fetch webpage info
  // save bookmark info in webpage
  // after 5 seconds, render all notes again.

  window.setTimeout(function () {
    layer.renderAllNotes();
  }, 5000);
};

var uiRender = /*#__PURE__*/Object.freeze({
	__proto__: null
});

var Runtime = /*@__PURE__*/getAugmentedNamespace(runtime);

var require$$5 = /*@__PURE__*/getAugmentedNamespace(uiRender);

var program$1 = new Runtime([activityLog, dbForeground, settings, uiListener, uiNotification, require$$5]); // debugger;


program$1.start();

var foreground = {

};

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

var messages$2 = require('../dbForeground/Message');

var com$2 = require('../dbForeground/communicate');

var NoteIndex$1 = require('./NoteIndex');

var getCurrentTab = require('../_utilities/tabs').getCurrentTab;

var isPageInBlackList = require('./blackList').isPageInBlackList;

var addPageToBlackList = require('./blackList').addPageToBlackList;

var removePageFromBlackList = require('./blackList').removePageFromBlackList;

var AnalyticsLogger$2 = require('./analytics');

var _require = require('../_utilities/aws');
    _require.AWS;
    var setupAWS = _require.setupAWS;

var htmlDocx = require('../_utilities/html-docx-js/api');

var _require2 = require('../dbForeground/communicate'),
    downloadOnlineFile = _require2.downloadOnlineFile,
    onMessage$1 = _require2.onMessage,
    requestPermission = _require2.requestPermission;

var searchIndex = require('../dbForeground/searchIndex');

var createWordExport = require('./export/wordExport').createWordExport;

var is = require('../_utilities/isType');

var createEvernoteExport = require('./export/evernoteExport').createEvernoteExport;

var sanitizeFilename = require('../_utilities/sanitize').sanitizeFilename;

var Account$2 = require('../actionPage/account');

var now = require('../_utilities/now');

var localDBName$1 = require('./LocalDBName');

var createNewDatabase = require("../appBackend/noteSyncing").createNewDatabase;

function getPageInfoId(pageIndex) {
  return "PAGEINFO::" + pageIndex;
}

function downloadLocalFile(fileBlob, filename) {
  filename = sanitizeFilename(filename);
  var download_link = document.createElement("a");
  download_link.style = "display: none";
  download_link.download = filename;
  document.body.appendChild(download_link);
  var objectURL = window.URL.createObjectURL(fileBlob);
  download_link.href = objectURL;
  requestPermission("downloads", function () {
    downloadOnlineFile(objectURL, filename, function (downloadId) {
      window.setTimeout(function () {
        window.URL.revokeObjectURL(objectURL);
        document.body.removeChild(download_link);
      }, 3000);
    });
  });
}

function convertImageFormat(imageElement, dataURL, callback) {
  var imgFormat = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 'image/png';
  var compress = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 0.92;
  var newImageNode = document.createElement('IMG');

  newImageNode.onload = function () {
    // preparing canvas for drawing
    var canvas = document.createElement('CANVAS');
    var ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height); // Set the width and height to the natural size of the image

    canvas.width = imageElement.naturalWidth;
    canvas.height = imageElement.naturalHeight;
    ctx.drawImage(newImageNode, 0, 0); // by default toDataURL() produces png image
    // usually jpg is preferred over png for better size-quality trade-off
    // however, jpg format does not work for some svg images

    var pngDataURL = canvas.toDataURL(imgFormat, compress);
    callback(pngDataURL);
  };

  newImageNode.src = dataURL;
}

function getImageBinary(imageElement, callback, errorHandler) {
  var imageSrc = imageElement.src;
  var httpRequest = new XMLHttpRequest();
  httpRequest.open('get', imageSrc);
  httpRequest.responseType = 'blob';

  httpRequest.onload = function () {
    // read the image content from the Blob
    var pReader = new FileReader();

    pReader.onload = function () {
      var dataURL = this.result; // check if the image is svg file.

      if (dataURL.startsWith('data:image/svg')) {
        convertImageFormat(imageElement, dataURL, callback);
      } else if (dataURL.length > 512 * 1024) {
        // check if the image size is larger than 500 KB.
        console.log('compressing triggered');
        convertImageFormat(imageElement, dataURL, callback, 'image/jpeg', 0.5);
      } else {
        callback(dataURL);
      }
    };

    pReader.readAsDataURL(httpRequest.response); // async call
  };

  httpRequest.onerror = function () {
    errorHandler(httpRequest.response);
  };

  httpRequest.send();
}

var BEANOTE_STAT_LAST_LOG_TIMESTAMP = 'BEANOTE_STAT_LAST_LOG_TIMESTAMP';
var STAT_LOG_PERIOD = 1000 * 60 * 60 * 24 * 3; // every 3 day

module.exports = /*#__PURE__*/asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee4() {
  var account, dbname, remote, noteIndex, indexBuildingPromise, logger, errorHandlerFunctor, findNotesInPage, _findNotesInPage;

  return regenerator.wrap(function _callee4$(_context4) {
    while (1) {
      switch (_context4.prev = _context4.next) {
        case 0:
          _findNotesInPage = function _findNotesInPage3() {
            _findNotesInPage = asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee3(urlInfo) {
              var pageIndex, r, notelist, _iterator, _step, doc;

              return regenerator.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      if (is.String(urlInfo)) {
                        urlInfo = new URL(urlInfo);
                      }

                      pageIndex = searchIndex.getSearchIndex(urlInfo);
                      _context3.next = 4;
                      return window.NoteDatabase.findNotesInPage(pageIndex);

                    case 4:
                      r = _context3.sent;
                      notelist = [];
                      _iterator = _createForOfIteratorHelper(r.docs);

                      try {
                        for (_iterator.s(); !(_step = _iterator.n()).done;) {
                          doc = _step.value;
                          notelist.push(doc);
                        }
                      } catch (err) {
                        _iterator.e(err);
                      } finally {
                        _iterator.f();
                      }

                      return _context3.abrupt("return", notelist);

                    case 9:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3);
            }));
            return _findNotesInPage.apply(this, arguments);
          };

          findNotesInPage = function _findNotesInPage2(_x) {
            return _findNotesInPage.apply(this, arguments);
          };

          errorHandlerFunctor = function _errorHandlerFunctor(request) {
            return function (err, sendResponse) {
              logger.error({
                event: 'BackgroundRequestError',
                error: err,
                request: {
                  type: request.type,
                  content: request.content
                }
              });
              sendResponse(null);
            };
          };

          com$2.setUpdateBadge(); // set up data storage database

          account = new Account$2();
          _context4.next = 7;
          return localDBName$1.getInitialLocalDBName();

        case 7:
          dbname = _context4.sent;
          _context4.next = 10;
          return account.getRemoteDBSetup();

        case 10:
          remote = _context4.sent;
          _context4.next = 13;
          return createNewDatabase(dbname, remote);

        case 13:
          // set up note query index
          noteIndex = new NoteIndex$1();
          indexBuildingPromise = window.NoteDatabase.createNoteIndexes(noteIndex); // create remote logger

          setupAWS();
          logger = AnalyticsLogger$2.get();
          logger.start({
            period: 60 * 1000
          }); // one minute
          // log db size, note count, page count

          indexBuildingPromise.then( /*#__PURE__*/asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee() {
            var ts, lastTs, numPages, numNotes, disk;
            return regenerator.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    window.NoteQueryIndex = noteIndex;
                    ts = now.now();
                    lastTs = localStorage.getItem(BEANOTE_STAT_LAST_LOG_TIMESTAMP);
                    lastTs = lastTs ? parseFloat(lastTs) : 0;

                    if (!(ts - lastTs > STAT_LOG_PERIOD)) {
                      _context.next = 12;
                      break;
                    }

                    numPages = Object.keys(noteIndex.pageRecordDict).length;
                    numNotes = noteIndex.noteList.length;
                    _context.next = 9;
                    return navigator.storage.estimate();

                  case 9:
                    disk = _context.sent;
                    logger.info({
                      event: 'stat',
                      diskUsage: disk.usage,
                      numNotes: numNotes,
                      numPages: numPages
                    });
                    localStorage.setItem(BEANOTE_STAT_LAST_LOG_TIMESTAMP, ts);

                  case 12:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee);
          })));
          // receive message from dbforeground.
          onMessage$1( /*#__PURE__*/function () {
            var _ref3 = asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee2(request, sender, sendResponse) {
              var errorHandler, pNote, deletedPage, notelist, searchResult, content, totalPages, notes, html, converted, xml, imageElement, pCheck, pAdd, pRemove;
              return regenerator.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      errorHandler = errorHandlerFunctor(request);
                      _context2.t0 = request.type;
                      _context2.next = _context2.t0 === messages$2.SaveNote ? 4 : _context2.t0 === messages$2.RemoveNote ? 10 : _context2.t0 === messages$2.FetchNoteList ? 14 : _context2.t0 === messages$2.SearchWebPage ? 26 : _context2.t0 === messages$2.FetchTotalPageData ? 29 : _context2.t0 === messages$2.GenerateExportedWord ? 33 : _context2.t0 === messages$2.GenerateExportedEvernote ? 56 : _context2.t0 === messages$2.GetImageInBackground ? 72 : _context2.t0 === messages$2.CheckBlackList ? 75 : _context2.t0 === messages$2.AddBlackList ? 78 : _context2.t0 === messages$2.RemoveBlackList ? 82 : _context2.t0 === messages$2.AnalyticsLog ? 85 : 87;
                      break;

                    case 4:
                      pNote = window.NoteDatabase.saveNote(request.id, request.content);
                      pNote.then(function (note) {
                        return sendResponse(note);
                      })["catch"](function (err) {
                        return errorHandler(err, sendResponse);
                      });
                      window.NoteQueryIndex.appendItem(request.id, request.content, request.content.urlId); // update the webpage when first create note on the page

                      if (request.updatePage) {
                        getCurrentTab().then(function (tab) {
                          request.pageInfo.favicon = tab.favIconUrl;
                          var pageInfoId = getPageInfoId(request.pageInfo.pageIndex);
                          window.NoteDatabase.saveWebPage(pageInfoId, request.pageInfo);
                          window.NoteQueryIndex.appendItem(pageInfoId, request.pageInfo, request.pageInfo.pageIndex);
                        })["catch"](function (err) {
                          console.error(err);
                        });
                      } // LOG: SaveNote
                      // comment: put logging code at the end of the target logic to avoid interfare existing function


                      logger.info({
                        event: 'SaveNote',
                        noteType: request.content.noteType,
                        url: request.content.urlId
                      });
                      return _context2.abrupt("break", 88);

                    case 10:
                      deletedPage = window.NoteQueryIndex.removeItem(request.id);
                      pNote = window.NoteDatabase.removeNote(request.id, request.content);
                      pNote.then(function (note) {
                        sendResponse(note);

                        if (deletedPage.isPageEmpty) {
                          // Delete the Webpage Entry in the database.
                          // Future feature: Advanced URL matching
                          window.NoteDatabase.removeWebPage(getPageInfoId(deletedPage.pageUrl));
                        }
                      })["catch"](function (err) {
                        return errorHandler(err, sendResponse);
                      });
                      return _context2.abrupt("break", 88);

                    case 14:
                      _context2.prev = 14;
                      _context2.next = 17;
                      return findNotesInPage(request.content);

                    case 17:
                      notelist = _context2.sent;
                      sendResponse(notelist); // @WARNING: comment this for the sake of easier debug advanced-url-matching

                      if (notelist.length == 0) {
                        window.NoteQueryIndex.removeItem(getPageInfoId(request.content));
                        window.NoteDatabase.removeWebPage(getPageInfoId(request.content));
                      }

                      _context2.next = 25;
                      break;

                    case 22:
                      _context2.prev = 22;
                      _context2.t1 = _context2["catch"](14);
                      errorHandler(_context2.t1, sendResponse);

                    case 25:
                      return _context2.abrupt("break", 88);

                    case 26:
                      searchResult = window.NoteQueryIndex.searchForKey(request.content);
                      sendResponse(searchResult);
                      return _context2.abrupt("break", 88);

                    case 29:
                      content = request.content || {}; // slice args = {start, end, order}

                      totalPages = window.NoteQueryIndex.getTotalPageData(content);
                      sendResponse(totalPages);
                      return _context2.abrupt("break", 88);

                    case 33:
                      _context2.prev = 33;
                      _context2.next = 36;
                      return findNotesInPage(request.content.url);

                    case 36:
                      notes = _context2.sent;
                      notes.sort(function (a, b) {
                        return a.position.top > b.position.top ? 1 : -1;
                      });
                      html = createWordExport(notes);

                      if (!request.content.htmlOnly) {
                        _context2.next = 44;
                        break;
                      }

                      request.content.filename += '.html';
                      converted = new Blob([html], {
                        type: 'application/html'
                      });
                      _context2.next = 47;
                      break;

                    case 44:
                      _context2.next = 46;
                      return htmlDocx.asBlob(html);

                    case 46:
                      converted = _context2.sent;

                    case 47:
                      logger.info({
                        event: 'GenerateExportedWord',
                        url: request.content.url,
                        fileSize: converted.size
                      });
                      downloadLocalFile(converted, request.content.filename);
                      _context2.next = 54;
                      break;

                    case 51:
                      _context2.prev = 51;
                      _context2.t2 = _context2["catch"](33);
                      errorHandler(_context2.t2, sendResponse);

                    case 54:
                      sendResponse();
                      return _context2.abrupt("break", 88);

                    case 56:
                      _context2.prev = 56;
                      _context2.next = 59;
                      return findNotesInPage(request.content.url);

                    case 59:
                      notes = _context2.sent;
                      notes.sort(function (a, b) {
                        return a.position.top > b.position.top ? 1 : -1;
                      });
                      xml = createEvernoteExport(request.content.noteTitle, notes);
                      converted = new Blob([xml], {
                        type: 'application/enex'
                      });
                      logger.info({
                        event: 'GenerateExportedEvernote',
                        url: request.content.url,
                        fileSize: converted.size
                      });
                      downloadLocalFile(converted, request.content.filename);
                      _context2.next = 70;
                      break;

                    case 67:
                      _context2.prev = 67;
                      _context2.t3 = _context2["catch"](56);
                      errorHandler(_context2.t3, sendResponse);

                    case 70:
                      sendResponse();
                      return _context2.abrupt("break", 88);

                    case 72:
                      imageElement = request.content;
                      getImageBinary(imageElement, function (dataURL) {
                        sendResponse(dataURL);
                      }, function (err) {
                        return errorHandler(err, sendResponse);
                      });
                      return _context2.abrupt("break", 88);

                    case 75:
                      pCheck = isPageInBlackList(request.content, window.NoteDatabase);
                      pCheck.then(function (answer) {
                        return sendResponse(answer);
                      })["catch"](function (err) {
                        return errorHandler(err, sendResponse);
                      });
                      return _context2.abrupt("break", 88);

                    case 78:
                      pAdd = addPageToBlackList(request.content, window.NoteDatabase);
                      pAdd.then(function (item) {
                        return sendResponse(item);
                      })["catch"](function (err) {
                        return errorHandler(err, sendResponse);
                      });
                      logger.info({
                        event: 'AddBlackList',
                        url: request.content
                      });
                      return _context2.abrupt("break", 88);

                    case 82:
                      pRemove = removePageFromBlackList(request.content, window.NoteDatabase);
                      pRemove.then(function (item) {
                        return sendResponse(item);
                      })["catch"](function (err) {
                        return errorHandler(err, sendResponse);
                      });
                      return _context2.abrupt("break", 88);

                    case 85:
                      logger.log(request.content.level || 'info', request.content.message || '', request.content.name || '');
                      return _context2.abrupt("break", 88);

                    case 87:
                      return _context2.abrupt("break", 88);

                    case 88:
                      return _context2.abrupt("return", true);

                    case 89:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, null, [[14, 22], [33, 51], [56, 67]]);
            }));

            return function (_x2, _x3, _x4) {
              return _ref3.apply(this, arguments);
            };
          }()); // This event is only sent from appBackend.

          /*
          var hub = window.BeenoteEventHub;
          hub.on(events.SaveNote, (note) => {
              window.NoteQueryIndex.appendItem(note.noteId, note, note.urlId);
              var pNote = window.NoteDatabase.saveNote(note.noteId, note);
              pNote.then(() => {})
                   .catch((err) => console.error(err));
          });
           hub.on(events.GetWebpageInfo, (pageIndex) => {
              var idList = [getPageInfoId(pageIndex)];
              var pSearch = window.NoteDatabase.getItemListByIds(idList);
              pSearch.then((itemList) => {
                  if (itemList.length == 1) {
                      pageInfo = itemList[0];
                      hub.emit(events.PushWebpageInfo, pageInfo);
                  } else {
                      hub.emit(events.PushWebpageInfo, null);
                  }
              }).catch((err) => console.error(err));
          });
          */
          // sync the database with the remote database
          // window.NoteDatabase.syncUpDatabase();

        case 20:
        case "end":
          return _context4.stop();
      }
    }
  }, _callee4);
}));

var dbBackground = /*#__PURE__*/Object.freeze({
	__proto__: null
});

var contextMenu = function () {
  function getMessage(menuItemId) {
    var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    return {
      menuId: menuItemId,
      type: "ContextMenuClick",
      content: data
    };
  }

  chrome.contextMenus.removeAll(function () {
    chrome.contextMenus.create({
      id: "StickerNote",
      title: "Create Sticker Note",
      contexts: ["all"]
    }); // TODO: Code it Later
    // chrome.contextMenus.create({ 
    //     id: "RectangleNote",
    //     title: 'Create Rectangle Note',
    //     contexts: ["all"]
    // })
  });
  /*
  chrome.contextMenus.create({
      id: "SavePage",
      title: "Beanote - Save Page with Notes",
      contexts: ["all"]
  });
  */

  chrome.contextMenus.onClicked.addListener(function (info, tab) {
    //console.log("item " + info.menuItemId + " was clicked");
    //console.log("info: " + JSON.stringify(info));
    if (info.menuItemId == "StickerNote") {
      chrome.tabs.sendMessage(tab.id, getMessage(info.menuItemId));
    } else if (info.menuItemId == "RectangleNote") {
      chrome.tabs.sendMessage(tab.id, getMessage(info.menuItemId));
    }
    /*
    if (info.menuItemId == "SavePage") {
        chrome.pageCapture.saveAsMHTML({tabId: tab.id}, function(mhtmlData) {
            var blobUrl = URL.createObjectURL(mhtmlData);
            chrome.tabs.sendMessage(tab.id, getMessage(info.menuItemId, blobUrl));
        });
    }
    */

  });
};

require('../config/frontend/events');

var messages$1 = require('../dbForeground/Message');

var onMessage = require('../dbForeground/communicate').onMessage;

require('./noteSharing').loadSharedNotes;

require('../_utilities/tabs').getCurrentTab;

var localDBName = require('../dbBackground/LocalDBName');

var Account$1 = require('../actionPage/account');

var NoteIndex = require('../dbBackground/NoteIndex');
/**
 * This function is not operational yet, since we want to ship email login first
 */


function setupOAuthSession(_x) {
  return _setupOAuthSession.apply(this, arguments);
}

function _setupOAuthSession() {
  _setupOAuthSession = asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee5(response) {
    return regenerator.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            if (!response.isNewUser) {
              _context5.next = 6;
              break;
            }

            _context5.next = 3;
            return localDBName.getLocalDBNameRegister(response.username);

          case 3:
            _context5.sent;
            _context5.next = 9;
            break;

          case 6:
            _context5.next = 8;
            return localDBName.getLocalDBNameLogin(response.username);

          case 8:
            _context5.sent;

          case 9:
            _context5.next = 11;
            return window.NoteDatabase.startSync();

          case 11:
            return _context5.abrupt("return");

          case 12:
          case "end":
            return _context5.stop();
        }
      }
    }, _callee5);
  }));
  return _setupOAuthSession.apply(this, arguments);
}

module.exports = /*#__PURE__*/asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee4() {
  var account;
  return regenerator.wrap(function _callee4$(_context4) {
    while (1) {
      switch (_context4.prev = _context4.next) {
        case 0:
          account = new Account$1();
          _context4.next = 4;
          return account.isLogined();

        case 4:
          if (!_context4.sent) {
            _context4.next = 7;
            break;
          }

          _context4.next = 7;
          return window.NoteDatabase.startSync();

        case 7:
          onMessage( /*#__PURE__*/function () {
            var _ref2 = asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee3(request, sender, sendResponse) {
              var account, username, localName;
              return regenerator.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.t0 = request.type;
                      _context3.next = _context3.t0 === messages$1.FacebookOAuthLogin ? 3 : _context3.t0 === messages$1.GoogleOAuthLogin ? 9 : _context3.t0 === messages$1.UserLogin ? 16 : _context3.t0 === messages$1.UserRegister ? 16 : _context3.t0 === messages$1.UserLogout ? 30 : 41;
                      break;

                    case 3:
                      _context3.next = 5;
                      return account.isLogined();

                    case 5:
                      if (!_context3.sent) {
                        _context3.next = 7;
                        break;
                      }

                      return _context3.abrupt("break", 42);

                    case 7:
                      account.signInWithFacebook(request.content, /*#__PURE__*/function () {
                        var _ref3 = asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee(response) {
                          return regenerator.wrap(function _callee$(_context) {
                            while (1) {
                              switch (_context.prev = _context.next) {
                                case 0:
                                  _context.next = 2;
                                  return setupOAuthSession(response);

                                case 2:
                                  sendResponse(response);

                                case 3:
                                case "end":
                                  return _context.stop();
                              }
                            }
                          }, _callee);
                        }));

                        return function (_x5) {
                          return _ref3.apply(this, arguments);
                        };
                      }(), function (error) {
                        sendResponse(null);
                      });
                      return _context3.abrupt("break", 42);

                    case 9:
                      account = new Account$1();
                      _context3.next = 12;
                      return account.isLogined();

                    case 12:
                      if (!_context3.sent) {
                        _context3.next = 14;
                        break;
                      }

                      return _context3.abrupt("break", 42);

                    case 14:
                      account.signInWithGoogle(request.content, /*#__PURE__*/function () {
                        var _ref4 = asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee2(response) {
                          return regenerator.wrap(function _callee2$(_context2) {
                            while (1) {
                              switch (_context2.prev = _context2.next) {
                                case 0:
                                  _context2.next = 2;
                                  return setupOAuthSession(response);

                                case 2:
                                  sendResponse(response);

                                case 3:
                                case "end":
                                  return _context2.stop();
                              }
                            }
                          }, _callee2);
                        }));

                        return function (_x6) {
                          return _ref4.apply(this, arguments);
                        };
                      }(), function (error) {
                        sendResponse(null);
                      });
                      return _context3.abrupt("break", 42);

                    case 16:
                      _context3.next = 18;
                      return account.getEmail();

                    case 18:
                      username = _context3.sent;
                      _context3.next = 21;
                      return localDBName.getInitialLocalDBName(username);

                    case 21:
                      localName = _context3.sent;
                      _context3.next = 24;
                      return localDBName.InitialSyncingMap.onceSeen(username);

                    case 24:
                      if (_context3.sent) {
                        _context3.next = 27;
                        break;
                      }

                      _context3.next = 27;
                      return localDBName.InitialSyncingMap.add(username);

                    case 27:
                      _context3.next = 29;
                      return window.BeenoteSyncClient.startSync();

                    case 29:
                      return _context3.abrupt("break", 42);

                    case 30:
                      _context3.next = 32;
                      return account.getEmail();

                    case 32:
                      username = _context3.sent;
                      _context3.next = 35;
                      return localDBName.getLocalDBNameLogout();

                    case 35:
                      localName = _context3.sent;
                      _context3.next = 38;
                      return window.NoteDatabase.stopSync();

                    case 38:
                      // Create a new local database and clean the note search index.
                      window.NoteDatabase = new NoteDB({
                        localName: localName
                      });
                      window.NoteQueryIndex = new NoteIndex();
                      return _context3.abrupt("break", 42);

                    case 41:
                      return _context3.abrupt("break", 42);

                    case 42:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3);
            }));

            return function (_x2, _x3, _x4) {
              return _ref2.apply(this, arguments);
            };
          }());
          /*
          hub.on(events.PushWebpageInfo, (pageInfo) => {
              if (pageInfo) {
                  // call createSharedLink();
              }
          });
          */

          /*
          userRegister(name, email, password, (result) => {
              console.log(result);
              storeUserCredential(name, email, password, () => {
              });
          }, (err) => {
              console.log(err);
          });
          */

        case 8:
        case "end":
          return _context4.stop();
      }
    }
  }, _callee4);
}));

var appBackend = /*#__PURE__*/Object.freeze({
	__proto__: null
});

var require$$1$1 = /*@__PURE__*/getAugmentedNamespace(dbBackground);

var require$$4 = /*@__PURE__*/getAugmentedNamespace(appBackend);

var program = new Runtime([activityLog, require$$1$1, settings, contextMenu, require$$4 // require('./test/dbTest') 
]);

program.start();

var style$1 = "\nimg {\n    user-select: none;\n}\n.editorContent img{\n    max-width: 80%;\n}\n.red {\n    stroke: #feb3c8;\n    fill: #FDC3D3;\n}\n.yellow {\n    stroke: #F9D06F;\n    fill: #F9D06F;\n}\n.blue {\n    stroke: #6CB1EF;\n    fill:  #6CB1EF;\n}\n.green {\n    stroke: #68c253;\n    fill: #68c253;\n}\n\n.svg-icon {\n    border-color: #E0E0E0;\n    background-color: rgba(247, 247, 247, 0.9);\n    border-width:1.5px;\n}\n.sticker{\n    fill:#9d8d49;\n}\n\n.sticker rect{\n    fill:#F9DB95;\n}\n.yellow .svg-icon {\n\n}\nbody, html{\n    height: auto;\n}\n\n.note-item{\n    background: #fff;\n    border-radius: 5px;\n    box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);\n    transition: all 0.3s cubic-bezier(.25,.8,.25,1);\n}\n.note-item:hover {\n   box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);\n}\n.note-item:active {\n   background-color: #eee;\n}\n\n.result{\n    padding-bottom:5px !important;\n}\n.results{\n    z-index: 100000 !important;\n    overflow-y: scroll;\n    max-height: 360px;\n}\n\n\n#bottom-tab .ui.bottom.attached.menu{\n    box-shadow: 0px -3px 5px rgba(0,0,0,.1), 0px 3px 5px rgba(0,0,0,.1);\n    margin-top: 2px;\n    display:flex;\n    border: 0px;\n    background-color: #EDEDED;\n}\n\n#bottom-tab .ui.bottom.attached.menu .item {\n    flex: 1;\n    display: inline-block;\n    text-align: center;\n}\n\n\n#outline.ui.segment {\n    margin: 0;\n    padding: 0;\n}\n\n#pages.ui.segment {\n    margin: 0;\n    padding: 0;\n}\n\n\n.menu.transition > .item > div.ui.checkbox > label {\n    padding-left: 2.1em\n}\n\n\n.hover-blue:hover {\n    color: #2185D0 !important;\n}\n\n#urls.ui.list>.item:last-child {\n    padding-bottom: .14285714em;\n}\n\n#snackbar {\n  visibility: hidden; /* Hidden by default. Visible on click */\n  min-width: 250px; /* Set a default minimum width */\n  margin-left: -125px; /* Divide value of min-width by 2 */\n  background-color: #333; /* Black background color */\n  color: #fff; /* White text color */\n  text-align: center; /* Centered text */\n  border-radius: 2px; /* Rounded borders */\n  padding: 16px; /* Padding */\n  position: fixed; /* Sit on top of the screen */\n  z-index: 1600000000000; /* Add a z-index if needed */\n  filter: none;\n  -webkit-filter:none;\n  left: 50%; /* Center the snackbar */\n  bottom: 30px; /* 30px from the bottom */\n  width: 70%;\n  white-space: normal;\n}\n\n/* Show the snackbar when clicking on a button (class added with JavaScript) */\n#snackbar.show {\n  visibility: visible; /* Show the snackbar */\n  /* Add animation: Take 0.5 seconds to fade in and out the snackbar.\n  However, delay the fade out process for 2.5 seconds */\n  -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;\n  animation: fadein 0.5s, fadeout 0.5s 2.5s;\n}\n\n/* Animations to fade the snackbar in and out */\n@-webkit-keyframes fadein {\n  from {bottom: 0; opacity: 0;}\n  to {bottom: 30px; opacity: 1;}\n}\n\n@keyframes fadein {\n  from {bottom: 0; opacity: 0;}\n  to {bottom: 30px; opacity: 1;}\n}\n\n@-webkit-keyframes fadeout {\n  from {bottom: 30px; opacity: 1;}\n  to {bottom: 0; opacity: 0;}\n}\n\n@keyframes fadeout {\n  from {bottom: 30px; opacity: 1;}\n  to {bottom: 0; opacity: 0;}\n}\n\n\n.ReactVirtualized__List:focus {\n    outline: none\n}\n.ReactVirtualized__List::-webkit-scrollbar-track {\n    background: none\n}\n.mark-red {\n    background-color: #FDC3D3;\n}\n.mark-green {\n    background-color: #CEF5C5;\n}\n.mark-yellow {\n    background-color: #F9DB95;\n}\n.mark-blue {\n    background-color: #6CB1EF;\n}\n\n.scrollbar-thin::-webkit-scrollbar{\n    width: 4px;\n}\n\n.note-content-card * {\n    max-width: 100% !important;\n    height: auto !important;\n    font-size: 13px !important;\n    white-space: initial !important;\n}\n\n.no-margin-children * {\n    margin: 0px;\n    padding: 0px\n}\n.no-margin-children ol {\n    padding-left:1.5em;\n}\n\n.red.ui.inverted.top.popup:before {\n    background: #db2828\n}\n\n#signin-notice-bubble {\n    z-index:100;\n}\n\n"; // 'red': '#FDC3D3',
// 'green': '#CEF5C5', // Tea Green
// 'yellow': '#F9DB95',
// 'blue': '#6CB1EF

var css = {
  style: style$1
};

var com$1 = require('./communicate');

var messages = require('./Message');

var AnalyticsLogger$1 = /*#__PURE__*/function () {
  function AnalyticsLogger(name) {
    classCallCheck(this, AnalyticsLogger);

    this.name = name;
  }

  createClass(AnalyticsLogger, [{
    key: "log",
    value: function log(level, msg) {
      com$1.sendMessage(com$1.createMessage(messages.AnalyticsLog, {
        level: level,
        message: msg,
        name: this.name
      }));
    }
  }, {
    key: "info",
    value: function info(message) {
      this.log('info', message);
    }
  }, {
    key: "warn",
    value: function warn(message) {
      this.log('warn', message);
    }
  }, {
    key: "error",
    value: function error(message) {
      this.log('error', message);
    }
  }, {
    key: "danger",
    value: function danger(message) {
      this.log('danger', message);
    }
  }]);

  return AnalyticsLogger;
}();

module.exports = AnalyticsLogger$1;

var analytics = /*#__PURE__*/Object.freeze({
	__proto__: null
});

/**
 * es6-weakmap.js
 * WeakMap (ECMA-262 6th Edition / ECMAScript 2015)
 *
 *
 * @version 0.9.2
 * @author think49
 * @url https://gist.github.com/think49/283b7374e352e09fc131
 * @license http://www.opensource.org/licenses/mit-license.php (The MIT License)
 * @see <a href="http://www.ecma-international.org/ecma-262/6.0/#sec-weakmap-constructor">23.3.1 The WeakMap Constructor – ECMA-262 6th Edition</a>
 */

if (typeof WeakMap !== 'function' && typeof Object.defineProperties === 'function') {
  var WeakMap = function (Object, isArray) {
    var weakMapDataList = []; // [[WeakMapData]] internal slot

    function WeakMap()
    /* [iterable] */
    {
      weakMapDataList.push([this, []]);
    }

    Object.defineProperties(WeakMap.prototype, {
      get: {
        writable: true,
        enumerable: false,
        configurable: true,
        value: function get(key) {
          if (Object(this) !== this) {
            // 2. If Type(thisArg) is not Object, throw a TypeError exception.
            throw new TypeError('Method WeakMap.prototype.get called on incompatible receiver ' + this);
          }

          var i = 0,
              l = weakMapDataList.length,
              weakMapData,
              map,
              data;

          while (i < l) {
            weakMapData = weakMapDataList[i++];

            if (weakMapData[0] === this) {
              if (Object(key) !== key) {
                // 5. If Type(key) is not Object, return undefined.
                return;
              }

              map = weakMapData[1];
              i = 0, l = map.length;

              while (i < l) {
                data = map[i++];

                if (data[0] === key) {
                  return data[1];
                }
              }

              return;
            }
          }

          throw new TypeError('Method WeakMap.prototype.get called on incompatible receiver ' + this); // 3. If thisArg does not have a [[WeakMapData]] internal slot, throw a TypeError exception.
        }
      },
      set: {
        writable: true,
        enumerable: false,
        configurable: true,
        value: function set(key, value) {
          if (Object(this) !== this) {
            // 2. If Type(thisArg) is not Object, throw a TypeError exception.
            throw new TypeError('Method WeakMap.prototype.set called on incompatible receiver ' + this);
          }

          var i = 0,
              l = weakMapDataList.length,
              weakMapData,
              map,
              data;

          while (i < l) {
            weakMapData = weakMapDataList[i++];

            if (weakMapData[0] === this) {
              if (Object(key) !== key) {
                // 5. If Type(key) is not Object, throw a TypeError exception.
                throw new TypeError('Invalid value used as weak map key');
              }

              map = weakMapData[1];
              i = 0, l = map.length;

              while (i < l) {
                data = map[i++];

                if (data[0] === key) {
                  data[1] = value;
                  return this;
                }
              }

              map.push([key, value]);
              return this;
            }
          }

          throw new TypeError('Method WeakMap.prototype.set called on incompatible receiver ' + this); // 3. If thisArg does not have a [[WeakMapData]] internal slot, throw a TypeError exception.
        }
      },
      has: {
        writable: true,
        enumerable: false,
        configurable: true,
        value: function has(key) {
          if (Object(this) !== this) {
            // 2. If Type(thisArg) is not Object, throw a TypeError exception.exception.
            throw new TypeError('Method WeakMap.prototype.has called on incompatible receiver ' + this);
          }

          var i = 0,
              l = weakMapDataList.length,
              weakMapData,
              map;

          while (i < l) {
            weakMapData = weakMapDataList[i++]; // [[WeakMapData]] internal slot

            if (weakMapData[0] === this) {
              if (Object(key) !== key) {
                // 5. If Type(key) is not Object, return false.
                return false;
              }

              map = weakMapData[1];
              i = 0, l = map.length;

              while (i < l) {
                if (map[i++][0] === key) {
                  return true;
                }
              }

              return false;
            }
          }

          throw new TypeError('Method WeakMap.prototype.has called on incompatible receiver ' + this); // 3. If thisArg does not have a [[WeakMapData]] internal slot, throw a TypeError exception.
        }
      },
      "delete": {
        writable: true,
        enumerable: false,
        configurable: true,
        value: function delete_(key) {
          // Note: If you specify the "delete" for SyntaxError occurs, it is replaced by "delete_"
          if (Object(this) !== this) {
            // 2. If Type(thisArg) is not Object, throw a TypeError exception.
            throw new TypeError('Method WeakMap.prototype.delete called on incompatible receiver ' + this);
          }

          var i = 0,
              l = weakMapDataList.length,
              weakMapData,
              map;

          while (i < l) {
            weakMapData = weakMapDataList[i++]; // [[WeakMapData]] internal slot

            if (weakMapData[0] === this) {
              if (Object(key) !== key) {
                // 5. If Type(key) is not Object, return false.
                return false;
              }

              map = weakMapData[1];
              i = 0, l = map.length;

              while (i < l) {
                if (map[i++][0] === key) {
                  weakMapData[1] = map.slice(0, i - 1).concat(map.slice(i));
                  return true;
                }
              }

              return false;
            }
          }

          throw new TypeError('Method WeakMap.prototype.delete called on incompatible receiver ' + this); // 3. If thisArg does not have a [[WeakMapData]] internal slot, throw a TypeError exception.
        }
      }
    });
    return WeakMap;
  }(Object);

  window.WeakMap = WeakMap;
}

var _typeof_1 = createCommonjsModule(function (module) {
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;
});

(function (root) {
  // Store setTimeout reference so promise-polyfill will be unaffected by
  // other code modifying setTimeout (like sinon.useFakeTimers())
  var setTimeoutFunc = setTimeout;

  function noop() {} // Polyfill for Function.prototype.bind


  function bind(fn, thisArg) {
    return function () {
      fn.apply(thisArg, arguments);
    };
  }

  function Promise(fn) {
    if (_typeof_1(this) !== 'object') throw new TypeError('Promises must be constructed via new');
    if (typeof fn !== 'function') throw new TypeError('not a function');
    this._state = 0;
    this._handled = false;
    this._value = undefined;
    this._deferreds = [];
    doResolve(fn, this);
  }

  function handle(self, deferred) {
    while (self._state === 3) {
      self = self._value;
    }

    if (self._state === 0) {
      self._deferreds.push(deferred);

      return;
    }

    self._handled = true;

    Promise._immediateFn(function () {
      var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;

      if (cb === null) {
        (self._state === 1 ? resolve : reject)(deferred.promise, self._value);
        return;
      }

      var ret;

      try {
        ret = cb(self._value);
      } catch (e) {
        reject(deferred.promise, e);
        return;
      }

      resolve(deferred.promise, ret);
    });
  }

  function resolve(self, newValue) {
    try {
      // Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
      if (newValue === self) throw new TypeError('A promise cannot be resolved with itself.');

      if (newValue && (_typeof_1(newValue) === 'object' || typeof newValue === 'function')) {
        var then = newValue.then;

        if (newValue instanceof Promise) {
          self._state = 3;
          self._value = newValue;
          finale(self);
          return;
        } else if (typeof then === 'function') {
          doResolve(bind(then, newValue), self);
          return;
        }
      }

      self._state = 1;
      self._value = newValue;
      finale(self);
    } catch (e) {
      reject(self, e);
    }
  }

  function reject(self, newValue) {
    self._state = 2;
    self._value = newValue;
    finale(self);
  }

  function finale(self) {
    if (self._state === 2 && self._deferreds.length === 0) {
      Promise._immediateFn(function () {
        if (!self._handled) {
          Promise._unhandledRejectionFn(self._value);
        }
      });
    }

    for (var i = 0, len = self._deferreds.length; i < len; i++) {
      handle(self, self._deferreds[i]);
    }

    self._deferreds = null;
  }

  function Handler(onFulfilled, onRejected, promise) {
    this.onFulfilled = typeof onFulfilled === 'function' ? onFulfilled : null;
    this.onRejected = typeof onRejected === 'function' ? onRejected : null;
    this.promise = promise;
  }
  /**
   * Take a potentially misbehaving resolver function and make sure
   * onFulfilled and onRejected are only called once.
   *
   * Makes no guarantees about asynchrony.
   */


  function doResolve(fn, self) {
    var done = false;

    try {
      fn(function (value) {
        if (done) return;
        done = true;
        resolve(self, value);
      }, function (reason) {
        if (done) return;
        done = true;
        reject(self, reason);
      });
    } catch (ex) {
      if (done) return;
      done = true;
      reject(self, ex);
    }
  }

  Promise.prototype['catch'] = function (onRejected) {
    return this.then(null, onRejected);
  };

  Promise.prototype.then = function (onFulfilled, onRejected) {
    var prom = new this.constructor(noop);
    handle(this, new Handler(onFulfilled, onRejected, prom));
    return prom;
  };

  Promise.all = function (arr) {
    var args = Array.prototype.slice.call(arr);
    return new Promise(function (resolve, reject) {
      if (args.length === 0) return resolve([]);
      var remaining = args.length;

      function res(i, val) {
        try {
          if (val && (_typeof_1(val) === 'object' || typeof val === 'function')) {
            var then = val.then;

            if (typeof then === 'function') {
              then.call(val, function (val) {
                res(i, val);
              }, reject);
              return;
            }
          }

          args[i] = val;

          if (--remaining === 0) {
            resolve(args);
          }
        } catch (ex) {
          reject(ex);
        }
      }

      for (var i = 0; i < args.length; i++) {
        res(i, args[i]);
      }
    });
  };

  Promise.resolve = function (value) {
    if (value && _typeof_1(value) === 'object' && value.constructor === Promise) {
      return value;
    }

    return new Promise(function (resolve) {
      resolve(value);
    });
  };

  Promise.reject = function (value) {
    return new Promise(function (resolve, reject) {
      reject(value);
    });
  };

  Promise.race = function (values) {
    return new Promise(function (resolve, reject) {
      for (var i = 0, len = values.length; i < len; i++) {
        values[i].then(resolve, reject);
      }
    });
  }; // Use polyfill for setImmediate for performance gains


  Promise._immediateFn = typeof setImmediate === 'function' && function (fn) {
    setImmediate(fn);
  } || function (fn) {
    setTimeoutFunc(fn, 0);
  };

  Promise._unhandledRejectionFn = function _unhandledRejectionFn(err) {
    if (typeof console !== 'undefined' && console) {
      console.warn('Possible Unhandled Promise Rejection:', err); // eslint-disable-line no-console
    }
  };
  /**
   * Set the immediate function to execute callbacks
   * @param fn {function} Function to execute
   * @deprecated
   */


  Promise._setImmediateFn = function _setImmediateFn(fn) {
    Promise._immediateFn = fn;
  };
  /**
   * Change the function to execute on unhandled rejection
   * @param {function} fn Function to execute on unhandled rejection
   * @deprecated
   */


  Promise._setUnhandledRejectionFn = function _setUnhandledRejectionFn(fn) {
    Promise._unhandledRejectionFn = fn;
  };

  if (!window.Promise) {
    window.Promise = Promise;
  }
})();

var EventEmitter = /*#__PURE__*/function () {
  function EventEmitter() {
    classCallCheck(this, EventEmitter);

    this.events = {};
  }

  createClass(EventEmitter, [{
    key: "on",
    value: function on(key, fun) {
      var replace = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
      var funList;
      if (replace) funList = [];else funList = this.events[key] || [];
      funList.push(fun);
      this.events[key] = funList;
      return this;
    }
  }, {
    key: "emit",
    value: function emit(key, arg) {
      var apply = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
      var funList = this.events[key] || [];

      if (apply) {
        if (!(arg instanceof Array)) {
          arg = [arg];
        }

        funList.forEach(function (f) {
          return f.apply(null, arg);
        });
      } else {
        funList.forEach(function (f) {
          return f(arg);
        });
      }

      return this;
    }
  }]);

  return EventEmitter;
}();

module.exports = EventEmitter;

var eventEmitter = /*#__PURE__*/Object.freeze({
	__proto__: null
});

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

var assertThisInitialized = _assertThisInitialized;

var setPrototypeOf = createCommonjsModule(function (module) {
function _setPrototypeOf(o, p) {
  module.exports = _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

module.exports = _setPrototypeOf;
});

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) setPrototypeOf(subClass, superClass);
}

var inherits = _inherits;

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof_1(call) === "object" || typeof call === "function")) {
    return call;
  }

  return assertThisInitialized(self);
}

var possibleConstructorReturn = _possibleConstructorReturn;

var getPrototypeOf = createCommonjsModule(function (module) {
function _getPrototypeOf(o) {
  module.exports = _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

module.exports = _getPrototypeOf;
});

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var React$1 = window.React;
var UI = window.semanticUIReact;
UI.Dimmer;
var Menu = UI.Menu;
var Icon = UI.Icon;
UI.Segment;
var Popup = UI.Popup;
var Modal = UI.Modal;
UI.Header;
UI.Button;
UI.Label;
UI.Message;
UI.Container;
UI.Form;

var com = require('../../dbForeground/communicate');

UI.Sidebar;
window.Constant.color;

require('../../config/frontend/events');

var constant = window.Constant;
var Tab = UI.Tab;

var REALEASE_NOTE = require('../../../release-notes/1.6.0.md');

var Account = require('../account'),
    account = new Account(); // components


var Pages = require('./Pages');

var Outline = require('./Outline');

var Settings = require('./Settings'); // const


var menuTabHeight = 41;
var menuContentHeight = constant.pageHeight - menuTabHeight - 2;
var CONTAINER_APP_LAST_ACTIVE_INDEX = 'CONTAINER_APP_LAST_ACTIVE_INDEX';

var App = /*#__PURE__*/function (_React$Component) {
  inherits(App, _React$Component);

  var _super = _createSuper(App);

  function App(props) {
    var _this;

    classCallCheck(this, App);

    _this = _super.call(this, props);

    var self = assertThisInitialized(_this);

    _this.state = {
      activeIndex: localStorage.getItem(CONTAINER_APP_LAST_ACTIVE_INDEX) || 0,
      releaseNoteIsOpen: false,
      settingsClickOnce: localStorage.getItem(CONTAINER_APP_LAST_ACTIVE_INDEX) == 2,
      syncStatus: '' // 'yes', 'no', 'loading', ''

    };

    var checkSyncStatus = /*#__PURE__*/function () {
      var _ref = asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee() {
        var status;
        return regenerator.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return account.getSyncingStatus();

              case 2:
                status = _context.sent;
                self.setState({
                  syncStatus: status
                });

              case 4:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function checkSyncStatus() {
        return _ref.apply(this, arguments);
      };
    }();

    checkSyncStatus();
    _this.checkSyncStatusRoutine = setInterval(checkSyncStatus, 1000);
    com.isUpdateBadge(function () {
      setTimeout(function () {
        self.setState({
          releaseNoteIsOpen: true
        });
        com.resetUpdateBadge();
      }, 300);
    });
    return _this;
  }

  createClass(App, [{
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      clearInterval(this.checkSyncStatusRoutine);
    }
  }, {
    key: "getPanes",
    value: function getPanes() {
      var contentStyle = {
        height: menuContentHeight + 'px',
        border: 0
      };
      var self = this;
      var status = {
        backgroundColor: '',
        loading: false,
        icon: ''
      };

      if (self.state.syncStatus == 'yes') {
        status.backgroundColor = '#21ba45';
        status.icon = 'checkmark';
      } else if (self.state.syncStatus == 'no') {
        status.icon = 'close';
        status.backgroundColor = '#db2828';
      } else if (self.state.syncStatus == 'loading') {
        status.loading = true;
        status.icon = 'sync';
        status.backgroundColor = '#6CB1EF';
      }

      return [{
        menuItem: /*#__PURE__*/React$1.createElement(Menu.Item, {
          key: "Note"
        }, /*#__PURE__*/React$1.createElement(Icon, {
          name: "list ol"
        }), "Notes"),
        render: function render() {
          return /*#__PURE__*/React$1.createElement(Tab.Pane, {
            attached: "top",
            id: "outline",
            style: contentStyle
          }, " ", /*#__PURE__*/React$1.createElement(Outline, null), " ");
        }
      }, {
        menuItem: /*#__PURE__*/React$1.createElement(Menu.Item, {
          key: "Pages"
        }, /*#__PURE__*/React$1.createElement(Icon, {
          name: "compass"
        }), "Pages"),
        render: function render() {
          return /*#__PURE__*/React$1.createElement(Tab.Pane, {
            attached: "top",
            id: "pages",
            style: contentStyle
          }, /*#__PURE__*/React$1.createElement(Pages, null));
        }
      }, {
        menuItem: /*#__PURE__*/React$1.createElement(Menu.Item, {
          key: "Settings",
          onClick: function onClick() {
            self.setState({
              settingsClickOnce: true
            });
          }
        }, /*#__PURE__*/React$1.createElement(Popup, {
          trigger: /*#__PURE__*/React$1.createElement("span", null, /*#__PURE__*/React$1.createElement(Icon, {
            name: "user"
          }), /*#__PURE__*/React$1.createElement("span", null, "Account", /*#__PURE__*/React$1.createElement("span", {
            style: {
              position: 'absolute',
              backgroundColor: status.backgroundColor,
              color: 'white',
              borderRadius: '10px',
              top: '20%',
              width: '14px',
              height: '12px',
              left: '80%',
              fontSize: '8px',
              lineHeight: 1.5,
              paddingLeft: '2px'
            }
          }, /*#__PURE__*/React$1.createElement(Icon, {
            name: status.icon,
            loading: status.loading
          })))),
          open: !self.state.settingsClickOnce && self.state.syncStatus == 'no',
          position: "top right",
          style: {
            backgroundColor: '#db2828'
          },
          className: "red",
          disabled: self.state.settingsClickOnce || self.state.syncStatus != 'no',
          content: /*#__PURE__*/React$1.createElement("span", null, "Sign in to sync your notes"),
          inverted: true,
          id: "signin-notice-bubble"
        })),
        render: function render() {
          return /*#__PURE__*/React$1.createElement(Tab.Pane, {
            attached: "top",
            style: contentStyle
          }, " ", /*#__PURE__*/React$1.createElement(Settings, null), " ");
        }
      }];
    }
  }, {
    key: "onTabChange",
    value: function onTabChange(event, data) {
      this.setState({
        activeIndex: data.activeIndex
      });

      if ([0, 1].includes(data.activeIndex)) {
        localStorage.setItem(CONTAINER_APP_LAST_ACTIVE_INDEX, data.activeIndex);
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var self = this;
      return /*#__PURE__*/React$1.createElement("div", {
        style: {
          height: '100%'
        }
      }, /*#__PURE__*/React$1.createElement(Tab, {
        size: 'large',
        renderActiveOnly: true,
        activeIndex: self.state.activeIndex,
        id: "bottom-tab",
        menu: {
          color: 'blue',
          attached: 'bottom'
        },
        panes: this.getPanes(),
        style: {
          height: '100%'
        },
        onTabChange: function onTabChange(a, b) {
          return _this2.onTabChange(a, b);
        }
      }), /*#__PURE__*/React$1.createElement(Modal, {
        open: this.state.releaseNoteIsOpen,
        onClose: function onClose() {
          return self.setState({
            releaseNoteIsOpen: false
          });
        }
      }, /*#__PURE__*/React$1.createElement(Modal.Header, null, "Release Note \uD83C\uDF89"), /*#__PURE__*/React$1.createElement(Modal.Content, {
        scrolling: true,
        closeIcon: true
      }, /*#__PURE__*/React$1.createElement(Modal.Description, null, /*#__PURE__*/React$1.createElement("div", {
        dangerouslySetInnerHTML: {
          __html: REALEASE_NOTE
        }
      })))));
    }
  }]);

  return App;
}(React$1.Component);

module.exports = App;

var App$1 = /*#__PURE__*/Object.freeze({
	__proto__: null
});

var AnalyticsLogger = /*@__PURE__*/getAugmentedNamespace(analytics);

var require$$1 = /*@__PURE__*/getAugmentedNamespace(eventEmitter);

var require$$2 = /*@__PURE__*/getAugmentedNamespace(App$1);

var style = css.style;



var logger = new AnalyticsLogger('actionPage/index'); // polyfill







window.main = function () {
  var ee = require$$1;

  var App = require$$2;

  window.BeenoteEventHub = new ee();
  dbForeground();
  var container = document.getElementById('root'); // insert css

  var css = document.createElement("style");
  css.type = "text/css";
  css.innerHTML = style;
  document.body.appendChild(css); // insert react app'

  window.ReactDOM.render( /*#__PURE__*/React.createElement(App, null), container); // LOG

  logger.info({
    event: 'open'
  });
};

exports.__moduleExports = foreground;
