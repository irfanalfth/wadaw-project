if (!window.nimbus_core) {
    window.PATCH = `filesystem:chrome-extension://${chrome.i18n.getMessage('@@extension_id')}/persistent/`

    window.requestFileSystem = window.requestFileSystem || window.webkitRequestFileSystem
    window.requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || window.msRequestAnimationFrame

    window.nimbus_core = {}

    window.is_firefox = window.nimbus_core.is_firefox = navigator.userAgent.toLowerCase().indexOf('firefox') !== -1
    window.is_chrome = window.nimbus_core.is_chrome = /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor) && !/OPR/.test(navigator.userAgent)
    window.is_opera = window.nimbus_core.is_opera = /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor) && /OPR/.test(navigator.userAgent)
    window.is_edge = window.nimbus_core.is_edge = /Edg/.test(navigator.userAgent)
    window.is_chrome_os = window.nimbus_core.is_chrome_os = /CrOS/.test(navigator.userAgent)
    window.is_macintosh = window.nimbus_core.is_macintosh = /(Mac|iPhone|iPod|iPad)/i.test(navigator.platform)
    window.is_macintosh = window.nimbus_core.is_mobile = /(Android|iPhone|iPod|iPad)/i.test(navigator.userAgent)
    window.is_windows = window.nimbus_core.is_windows = ['Win32', 'Win64', 'Windows', 'WinCE'].indexOf(navigator.platform) !== -1
    window.is_linux = window.nimbus_core.is_linux = (!window.nimbus_core.is_chrome_os || !window.nimbus_core.is_macintosh) && navigator.platform.indexOf('Linux') !== -1
    window.path = 'filesystem:chrome-extension://' + chrome.i18n.getMessage('@@extension_id') + '/persistent/'
    window.language = navigator.language

    window.nimbus_core.is_app = false

    try {
        const service = analytics.getService('screens_chrome')
        const tracker = service.getTracker('UA-67774717-27') // G-7ZKFB3S0PN   UA-67774717-27
        tracker.sendAppView('Global')
        // const SLACK_UPLOAD = analytics.EventBuilder.builder().category('click').action('uploadSlack');
        // tracker.send(SLACK_UPLOAD.label('Chocolate'));
        nimbus_core.analytics = {
            tracker,
            capture_save: analytics.EventBuilder.builder().category('click').action('capture_save'), // drive / local / nimbus / print / classroom
            capture_action: analytics.EventBuilder.builder().category('click').action('capture_action'), // function_name
            capture_limit_click: analytics.EventBuilder.builder().category('click').action('capture_limit'), // 5min_limit
            capture_limit_view: analytics.EventBuilder.builder().category('view').action('capture_limit'), // 5min_limit / entire_page
            capture_click: analytics.EventBuilder.builder().category('click').action('capture_click'), // watermark / buy_capture_pro / footer_notes / footer_desktop / footer_clipper / add_info / make_link_private
            capture_video: analytics.EventBuilder.builder().category('click').action('capture_video'), // trim_video / crop_video
            capture_banner_click: analytics.EventBuilder.builder().category('click').action('capture_marketing_banner'), // notes_pro / capture_pro / desktop_pro
            capture_banner_view: analytics.EventBuilder.builder().category('view').action('capture_marketing_banner'), // notes_pro / capture_pro / desktop_pro
            capture_banner_plan_click: analytics.EventBuilder.builder().category('click').action('capture_marketing_plan_banner'),
            capture_banner_plan_view: analytics.EventBuilder.builder().category('view').action('capture_marketing_plan_banner'),
        }
    } catch (e) {

    }

    nimbus_core.ga = function (key, label) {
        const measurement_id = 'G-7ZKFB3S0PN'
        const api_secret = '-zEiEfErS1uaUUpTePZ35A'
        const data = {
            // 'app_instance_id': null, //localStorage.appGlobalId,
            'client_id': localStorage.gaUserId, //localStorage.appGlobalId,
            "user_id": nscNimbus.user.id,
            'events': [
                {
                    'name': key,
                    'params': {
                        [key]: label
                    }
                }
            ]
        }

        $.ajax({
            url: `https://www.google-analytics.com/${0 ? 'debug/' : ''}mp/collect?measurement_id=${measurement_id}&api_secret=${api_secret}`,
            type: 'POST',
            data: JSON.stringify(data),
            contentType: 'application/json;',
            dataType: 'json',
            success: function () {
                console.log(arguments)
            }
        })

        if (nimbus_core.analytics && nimbus_core.analytics.hasOwnProperty(key) && nscExt.getOption('analyticsEnable')) {
            nimbus_core.analytics.tracker.send(nimbus_core.analytics[key].label(label))
        }
    }

// https://stackoverflow.com/questions/18922880/html5-canvas-resize-downscale-image-high-quality
    window.nimbus_core.downScaleCanvas = function (cv, scale) {
        if (!(scale < 1) || !(scale > 0)) return cv
        let sqScale = scale * scale // square scale = area of source pixel within target
        let sw = cv.width // source image width
        let sh = cv.height // source image height
        let tw = Math.floor(sw * scale) // target image width
        let th = Math.floor(sh * scale) // target image height
        let sx = 0, sy = 0, sIndex = 0 // source x,y, index within source array
        let tx = 0, ty = 0, yIndex = 0, tIndex = 0 // target x,y, x,y index within target array
        let tX = 0, tY = 0 // rounded tx, ty
        let w = 0, nw = 0, wx = 0, nwx = 0, wy = 0, nwy = 0 // weight / next weight x / y
        // weight is weight of current source point within target.
        // next weight is weight of current source point within next target's point.
        let crossX = false // does scaled px cross its current px right border ?
        let crossY = false // does scaled px cross its current px bottom border ?
        let sBuffer = cv.getContext('2d').getImageData(0, 0, sw, sh).data // source buffer 8 bit rgba
        let tBuffer = new Float32Array(3 * tw * th) // target buffer Float32 rgb
        let sR = 0, sG = 0, sB = 0 // source's current point r,g,b

        for (sy = 0; sy < sh; sy++) {
            ty = sy * scale // y src position within target
            tY = 0 | ty     // rounded : target pixel's y
            yIndex = 3 * tY * tw  // line index within target array
            crossY = (tY !== (0 | (ty + scale)))
            if (crossY) { // if pixel is crossing botton target pixel
                wy = (tY + 1 - ty) // weight of point within target pixel
                nwy = (ty + scale - tY - 1) // ... within y+1 target pixel
            }
            for (sx = 0; sx < sw; sx++, sIndex += 4) {
                tx = sx * scale // x src position within target
                tX = 0 | tx    // rounded : target pixel's x
                tIndex = yIndex + tX * 3 // target pixel index within target array
                crossX = (tX !== (0 | (tx + scale)))
                if (crossX) { // if pixel is crossing target pixel's right
                    wx = (tX + 1 - tx) // weight of point within target pixel
                    nwx = (tx + scale - tX - 1) // ... within x+1 target pixel
                }
                sR = sBuffer[sIndex]   // retrieving r,g,b for curr src px.
                sG = sBuffer[sIndex + 1]
                sB = sBuffer[sIndex + 2]
                if (!crossX && !crossY) { // pixel does not cross
                    // just add components weighted by squared scale.
                    tBuffer[tIndex] += sR * sqScale
                    tBuffer[tIndex + 1] += sG * sqScale
                    tBuffer[tIndex + 2] += sB * sqScale
                } else if (crossX && !crossY) { // cross on X only
                    w = wx * scale
                    // add weighted component for current px
                    tBuffer[tIndex] += sR * w
                    tBuffer[tIndex + 1] += sG * w
                    tBuffer[tIndex + 2] += sB * w
                    // add weighted component for next (tX+1) px
                    nw = nwx * scale
                    tBuffer[tIndex + 3] += sR * nw
                    tBuffer[tIndex + 4] += sG * nw
                    tBuffer[tIndex + 5] += sB * nw
                } else if (!crossX && crossY) { // cross on Y only
                    w = wy * scale
                    // add weighted component for current px
                    tBuffer[tIndex] += sR * w
                    tBuffer[tIndex + 1] += sG * w
                    tBuffer[tIndex + 2] += sB * w
                    // add weighted component for next (tY+1) px
                    nw = nwy * scale
                    tBuffer[tIndex + 3 * tw] += sR * nw
                    tBuffer[tIndex + 3 * tw + 1] += sG * nw
                    tBuffer[tIndex + 3 * tw + 2] += sB * nw
                } else { // crosses both x and y : four target points involved
                    // add weighted component for current px
                    w = wx * wy
                    tBuffer[tIndex] += sR * w
                    tBuffer[tIndex + 1] += sG * w
                    tBuffer[tIndex + 2] += sB * w
                    // for tX + 1; tY px
                    nw = nwx * wy
                    tBuffer[tIndex + 3] += sR * nw
                    tBuffer[tIndex + 4] += sG * nw
                    tBuffer[tIndex + 5] += sB * nw
                    // for tX ; tY + 1 px
                    nw = wx * nwy
                    tBuffer[tIndex + 3 * tw] += sR * nw
                    tBuffer[tIndex + 3 * tw + 1] += sG * nw
                    tBuffer[tIndex + 3 * tw + 2] += sB * nw
                    // for tX + 1 ; tY +1 px
                    nw = nwx * nwy
                    tBuffer[tIndex + 3 * tw + 3] += sR * nw
                    tBuffer[tIndex + 3 * tw + 4] += sG * nw
                    tBuffer[tIndex + 3 * tw + 5] += sB * nw
                }
            } // end for sx
        } // end for sy

        // create result canvas
        let resCV = document.createElement('canvas')
        resCV.width = tw
        resCV.height = th
        let resCtx = resCV.getContext('2d')
        let imgRes = resCtx.getImageData(0, 0, tw, th)
        let tByteBuffer = imgRes.data
        // convert float32 array into a UInt8Clamped Array
        let pxIndex = 0 //
        for (sIndex = 0, tIndex = 0; pxIndex < tw * th; sIndex += 3, tIndex += 4, pxIndex++) {
            tByteBuffer[tIndex] = 0 | (tBuffer[sIndex])
            tByteBuffer[tIndex + 1] = 0 | (tBuffer[sIndex + 1])
            tByteBuffer[tIndex + 2] = 0 | (tBuffer[sIndex + 2])
            tByteBuffer[tIndex + 3] = 255
        }
        // writing result to canvas.
        resCtx.putImageData(imgRes, 0, 0)
        return resCV
    }
    window.nimbus_core.scaleCanvas = function (canvas) { // nimbus_screenshot
        if (localStorage.imageOriginalResolution === 'true') {
            if (window.is_chrome) canvas = window.nimbus_core.downScaleCanvas(canvas, 1 / window.devicePixelRatio)
        } else {
            if (window.is_firefox) canvas = window.nimbus_core.downScaleCanvas(canvas, window.devicePixelRatio)
        }
        return canvas
    }
    window.nimbus_core.checkDifferent = function (arr) {
        for (let i = 0, l = arr.length; i < l - 1; i++) {
            for (let j = i + 1; j < l; j++) {
                if (arr[i] === arr[j] && +arr[i] !== 0) {
                    return false
                }
            }
        }
        return true
    }
    window.nimbus_core.toArrayBuffer = function (dataURL, cb) {
        let xhr = new XMLHttpRequest()
        xhr.open('GET', dataURL, true)
        xhr.responseType = 'arraybuffer'
        xhr.onload = function () {
            cb && cb(this.response)
        }
        xhr.send()
    }
    window.nimbus_core.setOption = function (key, value) {
        localStorage[key] = value
        if (window.nimbus_core.is_chrome) return
        nscCore.syncSendMessage({ operation: 'set_option', key: key, value: value })
    }
    window.nimbus_core.setEvent = function (key, value) {
        chrome.runtime.sendMessage({ operation: 'event', type: key, value: value })
    }
    window.nimbus_core.customError = function (name, message) {
        let e = new Error(message)
        e.name = name
        return e
    }
    window.nimbus_core.getVideoFileName = function (info, format) {
        let s = localStorage.fileNamePatternScreencast
        let url = document.createElement('a')
        url.href = info.url || ''
        s = s.replace(/\{url}/, info.url || '')
            .replace(/\{title}/, info.title || '')
            .replace(/\{domain}/, url.host || '')
            .replace(/\{date}/, info.time.split(' ')[0] || '')
            .replace(/\{time}/, info.time.split(' ')[1] || '')
            .replace(/\{ms}/, info.time.split(' ')[2] || '')
            .replace(/\{timestamp}/, info.time.split(' ')[3] || '')

        return s.replace(/[\*\|\\\:\"\<\>\?\/#]+/ig, '_') + (format ? '.' + format : '')
    }
    window.nimbus_core.getImageFileName = function (info, format) {
        let s = localStorage.fileNamePatternScreenshot
        let url = document.createElement('a')
        url.href = info.url || ''
        s = s.replace(/\{url}/, info.url || '')
            .replace(/\{title}/, info.title || '')
            .replace(/\{domain}/, url.host || '')
            .replace(/\{date}/, info.time.split(' ')[0] || '')
            .replace(/\{time}/, info.time.split(' ')[1] || '')
            .replace(/\{ms}/, info.time.split(' ')[2] || '')
            .replace(/\{timestamp}/, info.time.split(' ')[3] || '')

        return s.replace(/[\*\|\\\:\"\<\>\?\/#]+/ig, '_') + (format ? '.' + format : '')
    }
    window.nimbus_core.addStyleSheet = function (id, css) {
        if (!document.getElementById(id)) {
            let head = document.head || document.getElementsByTagName('head')[0]
            let style = document.createElement('style')
            style.type = 'text/css'
            style.id = id
            head.appendChild(style)
            style.appendChild(document.createTextNode(css))
        }
    }
    window.nimbus_core.getSizePage = function () {
        const body = document.body
        const html = document.documentElement
        let totalWidth = [], totalHeight = []

        if (html && html.clientWidth) totalWidth.push(html.clientWidth)
        if (html && html.scrollWidth) totalWidth.push(html.scrollWidth)
        if (html && html.offsetWidth) totalWidth.push(html.offsetWidth)
        if (body && body.scrollWidth) totalWidth.push(body.scrollWidth)
        if (body && body.offsetWidth) totalWidth.push(body.offsetWidth)

        if (html && html.clientHeight) totalHeight.push(html.clientHeight)
        if (html && html.scrollHeight) totalHeight.push(html.scrollHeight)
        if (html && html.offsetHeight) totalHeight.push(html.offsetHeight)
        if (body && body.scrollHeight) totalHeight.push(body.scrollHeight)
        if (body && body.offsetHeight) totalHeight.push(body.offsetHeight)

        return {
            w: Math.max.apply(null, totalWidth),
            h: Math.max.apply(null, totalHeight)
        }
    }

    window.nimbus_core.async = function (operations, callback) {
        if (Array.isArray(operations) && operations.length < 1) {
            return callback([])
        }

        Promise.all(operations).then(function (results) {
            callback(results)
        }).catch(function (error) {
            return callback(error)
        })
    }

    window.nimbus_core.arrayToObject = function (array, keyField) {
        array.reduce(function (obj, item) {
            return obj[item[keyField]] = item
        }, 0)
        return array
    }

    window.nimbus_core.createUid = function () {
        function S4 () {
            return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1)
        }

        return S4() + S4() + S4() + S4()
    }

    // window.nimbus_core.storageUsageAndQuota = function () {
    //     return new Promise(function (resolve, reject) {
    //
    //         navigator.webkitPersistentStorage.queryUsageAndQuota(
    //             function (usedBytes, quotaBytes) {
    //                 // console.log('Storage are using ', usedBytes, ' of ', quotaBytes, 'bytes');
    //                 // localStorage.storageUsedBytes = usedBytes;
    //                 // localStorage.storageQuotaBytes = quotaBytes;
    //
    //                 resolve({used: usedBytes, quota: quotaBytes});
    //             }, function (e) {
    //                 console.error(e);
    //                 reject(e)
    //             }
    //         );
    //     });
    // };

    window.nimbus_core.pageScroll = async function (offsetX, offsetY, elem) {
        const scrollElem = elem || (document.scrollingElement || document.body)
        scrollElem.scrollLeft = offsetX
        scrollElem.scrollTop = offsetY
        await window.nimbus_core.timeout(100)
    }

    window.nimbus_core.timeout = function (timeout) {
        return new Promise(function (resolve, reject) {
            window.setTimeout(resolve, timeout)
        })
    }

    window.nimbus_core.getPageInfo = function (type) {
        return new Promise(function (resolve, reject) {
            chrome.tabs.query({ active: true }, function (tabs) {
                let info = { id: tabs[0].id, windowId: tabs[0].windowId, url: tabs[0].url, title: tabs[0].title, time: nscExt.getTimeStamp() }
                if (type === 'desktop' || type === 'capture-window') {
                    info.title = ''
                    info.url = ''
                }
                resolve(JSON.stringify(info))
            })
        })
    }

    window.nimbus_core.setExtensionBadge = function (countdown) {
        return new Promise(function (resolve, reject) {
            (function setBadge () {
                if (!screenshot.videoRecorder.getStatus()) {
                    return reject('recorder is stop')
                }
                if (countdown > 0) {
                    chrome.browserAction.setBadgeText({ text: countdown.toString() })
                    chrome.browserAction.setBadgeBackgroundColor({ color: '#000' })
                    countdown--
                    setTimeout(setBadge, 1000)
                } else {
                    chrome.browserAction.setBadgeText({ text: '' })
                    resolve()
                }
            })()
        })
    }

    window.nimbus_core.setActiveTab = function (tab) {
        return new Promise(function (resolve, reject) {
            chrome.tabs.highlight({ tabs: tab.index }, resolve)
        })
    }

    window.nimbus_core.setTimerContent = function (tab, countdown) {
        return new Promise(async function (resolve, reject) {

            chrome.browserAction.setPopup({ popup: '' })
            await window.nimbus_core.setActiveTab(tab)
            chrome.tabs.sendMessage(tab.id, { operation: 'content_start_timer', countdown: countdown })

            let timeout = setTimeout(function () {
                chrome.browserAction.setPopup({ popup: 'popup.html' })
                resolve(false)
            }, countdown * 1000 + 500)

            chrome.runtime.onMessage.addListener(function onMessage (request) {
                switch (request.operation) {
                    case 'content_end_timer':
                        chrome.runtime.onMessage.removeListener(onMessage)
                        chrome.browserAction.setPopup({ popup: 'popup.html' })
                        clearInterval(timeout)
                        resolve(request.type)
                        break
                    case 'content_stop_timer':
                        chrome.runtime.onMessage.removeListener(onMessage)
                        chrome.browserAction.setPopup({ popup: 'popup.html' })
                        clearInterval(timeout)
                        reject(request.type)
                        break
                }
            })
        })
    }

    window.nimbus_core.setIframeMediaCamera = function (constraints) {
        return new Promise(function (resolve, reject) {
            let iframe = document.createElement('iframe')
            iframe.setAttribute('allow', 'camera; microphone;')
            iframe.setAttribute('style', 'display: none')
            iframe.setAttribute('src', chrome.runtime.getURL('template/frame-media.html?' + JSON.stringify(constraints)))

            window.addEventListener('message', function (e) {
                try {
                    let data = JSON.parse(e.data)
                    if (data && data.action === 'nsc_frame_create_video') resolve({ iframe: iframe, value: data.value })
                } catch (e) {

                }
            }, false)

            document.body.appendChild(iframe)
        })
    }

    if (window.is_firefox) window.nimbus_core.path = 'filesystem:moz-extension://' + chrome.i18n.getMessage('@@extension_id') + '/persistent/'

    document.addEventListener('DOMContentLoaded', function () {
        let show_chrome_only = document.getElementsByClassName('show-chrome-only')
        let show_firefox_only = document.getElementsByClassName('show-firefox-only')
        let hide_chrome_only = document.getElementsByClassName('hide-chrome-only')
        let hide_firefox_only = document.getElementsByClassName('hide-firefox-only')
        let hide_linux_only = document.getElementsByClassName('hide-linux-only')

        for (let sco of show_chrome_only) {
            let display = sco.style.display
            sco.style.display = 'none'
            if (window.nimbus_core.is_chrome) sco.style.display = display
        }

        for (let sfo of show_firefox_only) {
            let display = sfo.style.display
            sfo.style.display = 'none'
            if (window.nimbus_core.is_firefox) sfo.style.display = display
        }

        for (let hco of hide_chrome_only) {
            if (window.nimbus_core.is_chrome) hco.style.display = 'none'
        }

        for (let hfo of hide_firefox_only) {
            if (window.nimbus_core.is_firefox) hfo.style.display = 'none'
        }

        for (let hfo of hide_linux_only) {
            if (window.nimbus_core.is_linux) hfo.style.display = 'none'
        }

    })
}
