/*
 * "This work is created by NimbusWeb and is copyrighted by NimbusWeb. (c) 2017 NimbusWeb.
 * You may not replicate, copy, distribute, or otherwise create derivative works of the copyrighted
 * material without prior written permission from NimbusWeb.
 *
 * Certain parts of this work contain code licensed under the MIT License.
 * https://www.webrtc-experiment.com/licence/ THE SOFTWARE IS PROVIDED "AS IS",
 * WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * */

(function () {
    if (window.__nscContentScriptCrop) return
    window.__nscContentScriptCrop = true
    let overflowLast = 'visible';
    window.thisCrop = false
    window.thisVideoCrop = false

    const cropStart = async function (image) {
        afterClearCapture()

        await nscCropper.setImage(image)
        await nscCropper.setOptions({ wrapperFull: false, scrollEnable: false })
        await nscCropper.mounted()
        await nscCropper.openPopup()

        const { x, y, w, h } = await nscCore.sendMessage({ operation: 'get_crop_position' })

        if (x && y && w && h) {
            const { pageYOffset, pageXOffset } = window
            nscCropper.setPoints({ x: x + pageXOffset, y: y + pageYOffset, w, h })
            nscCropper.render()
        }
    }

    const cropVideoStart = async function () {
        await nscCropper.setOptions({ wrapperFull: false, scrollEnable: false })
        await nscCropper.mounted(true)
    }

    nscCropper.on('removePopup', function () {
        if (!window.thisCrop) return
        nscCore.syncSendMessage({ operation: 'set_option', key: 'popupActionMessageCrop', value: 'true' })
    })

    nscCropper.on('destroy', function () {
        if (!window.thisCrop && !window.thisVideoCrop) return

        if (!window.thisVideoCrop) {
            beforeClearCapture(true)
        }

        window.thisCrop = false
        window.thisVideoCrop = false
    })

    nscCropper.on('end', function () {
        if (!window.thisCrop && !window.thisVideoCrop) return
        const z = window.devicePixelRatio

        if (!window.thisVideoCrop) {
            chrome.runtime.sendMessage({ operation: 'save_crop_position', value: { z, ...nscCropper.getFinishPoints() } })
        } else {
            const { innerWidth, innerHeight } = window
            chrome.runtime.sendMessage({ operation: 'save_video_crop', value: { z, ...nscCropper.getFinishPoints(), innerWidth, innerHeight } })
        }
    })

    nscCropper.on('action', function (action) {
        if (!window.thisCrop && !window.thisVideoCrop) return

        switch (action) {
            case 'edit':
            case 'download':
            case 'nimbus':
            case 'slack':
            case 'google':
            case 'quick':
            case 'print':
            case 'pdf':
            case 'copy_to_clipboard':
                chrome.runtime.sendMessage({ operation: 'send_to', path: action })
                window.thisCrop = false
                break
            case 'cancel':
                document.documentElement.style.overflow = overflowLast;
                break
            case 'record':
                chrome.runtime.sendMessage({ operation: 'video_crop_start' })
                window.thisVideoCrop = true
                cropVideoStart().then(async () => {
                    const { x, y, w, h } = await nscCore.sendMessage({ operation: 'get_crop_video_position' })

                    if (x && y && w && h) {
                        const { pageYOffset, pageXOffset } = window
                        nscCropper.setPoints({ x: x + pageXOffset, y: y + pageYOffset, w, h })
                        nscCropper.render()
                        nscCropper.destroyInversion()
                    }
                })

                break
        }
    })

    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.operation === 'crop_video_screen' && request.typeCapture === 'tab-select') {
            window.thisVideoCrop = true
            cropVideoStart().then(async () => {
                const overflow = document.documentElement.style.overflow;
                if(overflow && overflow !== 'hidden') {
                    overflowLast = document.documentElement.style.overflow
                }
                document.documentElement.style.overflow = 'hidden';
                if (request.autoCrop) {
                    const { x, y, w, h } = await nscCore.sendMessage({ operation: 'get_crop_video_position' })

                    if (x && y && w && h) {
                        const { pageYOffset, pageXOffset } = window
                        nscCropper.setPoints({ x: x + pageXOffset, y: y + pageYOffset, w, h })
                        nscCropper.render()
                        nscCropper.destroyInversion()
                    }
                }
            })
        }
        if (request.operation === 'crop_data_screen') {
            window.thisCrop = true
            cropStart(request.dataUrl).then(r => {})
        }
        if (request.operation === 'crop_after_clear_capture') {
            afterClearCapture()
            sendResponse()
        }

        if (request.operation === 'status_video' && !request.status) {
            nscCropper.destroy()
            document.documentElement.style.overflow = overflowLast;
        }
    })
}())
